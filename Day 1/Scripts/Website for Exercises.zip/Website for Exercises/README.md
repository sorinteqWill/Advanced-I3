# Offline Mock Target Bundle (Advanced+)

This bundle gives you a self-contained local target for course modules covering:
- silent HTML extraction
- internal/external link harvesting
- asset extraction (`.pdf`, `.docx`, `.jpg`, `.png`)
- offline forensic analysis of saved HTML
- basic WAF/header detection against a local server
- browser-vs-CLI behaviour comparison via local telemetry and tracking pixel logs
- spider-trap demonstration paths
- nested relative URL reconstruction
- local JSON APIs for dashboard/search-style exercises
- a fake authenticated portal area powered by local session storage and local JSON
- a mock Cloudflare-style JavaScript challenge for selected routes
- a broader site structure (`/company`, `/services`, `/news`, `/legal`, `/portal`)

## Quick start

### Full training mode
```bash
python start_target.py --port 8765
```

Then browse to:
```text
http://127.0.0.1:8765/
```

This mode adds mock WAF-style headers, writes structured access logs, accepts local telemetry posts, serves a tracking pixel, exposes simple APIs, rate-limits repeated sensitive requests, provides a crawler-trap path, and presents a JavaScript challenge on selected routes.

### Static mode only
```bash
cd site
python -m http.server 8765
```

This serves the pages and files, but not the telemetry, challenge logic, or JSON APIs.

## Demo portal notes
- Visit `/login.html` or `/portal/dashboard.html`
- In full training mode, browsers may get a JavaScript challenge before selected sensitive pages
- The demo portal stores a local session flag in `sessionStorage`
- Raw script requests often receive a challenge page or block instead
