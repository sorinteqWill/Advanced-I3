(function(){
  const KEY = 'asteriaDemoSession';
  function hasDemo(){
    try {
      const raw = sessionStorage.getItem(KEY);
      if (!raw) return false;
      const parsed = JSON.parse(raw);
      return !!parsed.enabled;
    } catch (e) {
      return false;
    }
  }
  function setDemo(){
    sessionStorage.setItem(KEY, JSON.stringify({token:'AG-DEMO-2026', enabled:true, at:new Date().toISOString()}));
  }
  function clearDemo(){
    sessionStorage.removeItem(KEY);
  }
  function card(label, value){
    return `<div class="card stat-card"><div class="label">${label}</div><div class="kpi">${value}</div></div>`;
  }
  function stackItem(title, meta){
    return `<div class="stack-item"><span>${title}</span><small>${meta}</small></div>`;
  }
  async function load(){
    const banner = document.querySelector('#portal-access-banner');
    const kpis = document.querySelector('#portal-kpis');
    const counterparties = document.querySelector('#portal-counterparties');
    const messages = document.querySelector('#portal-messages');
    const links = document.querySelector('#portal-vault-links');
    const enableBtn = document.querySelector('#portal-enable-demo');
    const clearBtn = document.querySelector('#portal-clear-demo');
    enableBtn?.addEventListener('click', ()=>{ setDemo(); load(); });
    clearBtn?.addEventListener('click', ()=>{ clearDemo(); load(); });
    let snapshot = null;
    try {
      const res = await fetch('/api/portal-snapshot');
      snapshot = await res.json();
    } catch (e) {}
    const authed = hasDemo();
    banner.innerHTML = authed
      ? '<h3>Demo access enabled</h3><p class="muted">The dashboard is rendering the fuller local training snapshot.</p>'
      : '<h3>Restricted preview</h3><p class="muted">Enable demo access to reveal the full local portal state. The page remains useful for HTML capture and asset discovery even in restricted mode.</p>';
    if (!snapshot) {
      kpis.innerHTML = '<div class="alert">Portal snapshot API unavailable. Start the bundle with start_target.py for full training mode.</div>';
      return;
    }
    kpis.innerHTML = [
      card('Desk', snapshot.desk),
      card('Timezone', snapshot.timezone),
      card('Pending cases', snapshot.counters.pending_cases),
      card('High-risk corridors', snapshot.counters.high_risk_corridors)
    ].join('');
    counterparties.innerHTML = snapshot.counterparties.map(item => stackItem(item.name, authed ? `${item.region} • ${item.status}` : `${item.region} • details hidden`)).join('');
    messages.innerHTML = snapshot.messages.map(item => stackItem(item.subject, authed ? `${item.priority} • ${item.owner}` : `${item.priority} • owner hidden`)).join('');
    links.innerHTML = snapshot.vault_links.map(path => `<a class="stack-item" href="${path}"><span>${path.split('/').pop()}</span><small>${path}</small></a>`).join('');
    document.querySelectorAll('[data-auth-required="true"]').forEach(el => el.classList.toggle('is-locked', !authed));
  }
  document.addEventListener('DOMContentLoaded', load);
})();
