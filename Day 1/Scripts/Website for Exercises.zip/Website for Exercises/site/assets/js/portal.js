(function(){
  const KEY = 'asteriaDemoSession';
  const TOKEN = 'AG-DEMO-2026';
  function enableDemo(){
    sessionStorage.setItem(KEY, JSON.stringify({token:TOKEN, enabled:true, at:new Date().toISOString()}));
    location.href = '/portal/dashboard.html';
  }
  document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('#portal-login');
    const demoBtn = document.querySelector('#demo-access');
    demoBtn?.addEventListener('click', enableDemo);
    if (!form) return;
    form.addEventListener('submit', (ev) => {
      ev.preventDefault();
      const out = document.querySelector('#login-message');
      const client = document.querySelector('#client-id')?.value.trim();
      const email = document.querySelector('#email')?.value.trim();
      if (!client || !email) {
        out.innerHTML = '<div class="alert">Training login needs a client ID and email before the local demo session is enabled.</div>';
        return;
      }
      sessionStorage.setItem(KEY, JSON.stringify({token:TOKEN, client, email, enabled:true, at:new Date().toISOString()}));
      out.innerHTML = '<div class="alert">Training portal only: enabling local demo session and redirecting to the dashboard.</div>';
      setTimeout(() => { location.href = '/portal/dashboard.html'; }, 450);
    });
  });
})();
