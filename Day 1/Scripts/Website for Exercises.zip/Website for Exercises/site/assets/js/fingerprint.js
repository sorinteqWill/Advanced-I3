// Mock trap script for training: records client-side context to the local lab server.
// Students should compare this with what a raw CLI fetch does not trigger.
window.__mockRiskFlags = {
  timezoneMismatch: Intl.DateTimeFormat().resolvedOptions().timeZone !== 'UTC',
  webdriver: !!navigator.webdriver,
  missingPlugins: !navigator.plugins || navigator.plugins.length === 0,
  touchpoints: navigator.maxTouchPoints || 0
};
