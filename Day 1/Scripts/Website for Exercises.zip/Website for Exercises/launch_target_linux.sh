#!/usr/bin/env bash
python3 start_target.py --port 8765
