from __future__ import annotations

import argparse
import json
import os
import time
from collections import Counter, defaultdict, deque
from datetime import datetime, timezone
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import parse_qs, quote, urlparse

ROOT = Path(__file__).resolve().parent
SITE = ROOT / 'site'
LOG_DIR = ROOT / 'logs'
LOG_DIR.mkdir(exist_ok=True)
PIXEL = bytes.fromhex('47494638396101000100800000000000ffffff21f90401000001002c00000000010001000002024401003b')
REQUEST_LOG = deque(maxlen=160)
PATH_COUNTS = Counter()
IP_RECENT = defaultdict(deque)
SUSPICIOUS_HITS = 0
BRIEFINGS = json.loads((SITE / 'assets' / 'data' / 'briefings.json').read_text(encoding='utf-8'))
PORTAL_SNAPSHOT = json.loads((SITE / 'assets' / 'data' / 'portal_snapshot.json').read_text(encoding='utf-8'))
SEARCH_INDEX = [
    {"title": "Document vault", "path": "/docs.html", "tags": ["documents", "vault", "pdf", "docx"]},
    {"title": "Nested archive index", "path": "/vault/archive/index.html", "tags": ["vault", "relative", "downloads"]},
    {"title": "Status dashboard", "path": "/status.html", "tags": ["telemetry", "status", "api"]},
    {"title": "Quarterly bulletin", "path": "/reports/quarterly.html", "tags": ["bulletin", "corridor", "zurich", "tbilisi"]},
    {"title": "Backup notes", "path": "/backup/ops-note.txt", "tags": ["backup", "ops", "notes", "mailbox"]},
    {"title": "Staging preview", "path": "/admin/staging.html", "tags": ["staging", "admin", "preview"]},
    {"title": "Team page", "path": "/company/team.html", "tags": ["company", "leadership", "contacts"]},
    {"title": "Portal dashboard", "path": "/portal/dashboard.html", "tags": ["portal", "dashboard", "auth"]},
    {"title": "Portal files", "path": "/portal/files.html", "tags": ["portal", "files", "downloads"]},
    {"title": "Compliance framework", "path": "/legal/compliance.html", "tags": ["legal", "compliance", "screening"]},
]
SENSITIVE_PATHS = {
    '/login.html',
    '/portal/dashboard.html',
    '/portal/files.html',
    '/vault/archive/index.html',
    '/admin/staging.html',
    '/company/team.html',
}


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def read_telemetry_count() -> int:
    p = LOG_DIR / 'telemetry.jsonl'
    if not p.exists():
        return 0
    with p.open('r', encoding='utf-8') as f:
        return sum(1 for _ in f)


class MockTargetHandler(SimpleHTTPRequestHandler):
    server_version = 'cloudflare'
    sys_version = ''

    def __init__(self, *args, directory=None, **kwargs):
        self._last_response_code = 200
        super().__init__(*args, directory=str(SITE), **kwargs)

    def send_response(self, code, message=None):
        self._last_response_code = code
        super().send_response(code, message)

    def _record(self, method: str, path: str, status: int):
        global SUSPICIOUS_HITS
        ua = self.headers.get('User-Agent', '')
        entry = {
            'ts': now_iso(),
            'ip': self.client_address[0],
            'method': method,
            'path': path,
            'status': status,
            'ua': ua[:110] or '-',
            'referer': self.headers.get('Referer', '')
        }
        REQUEST_LOG.appendleft(entry)
        PATH_COUNTS[path] += 1
        with (LOG_DIR / 'access.log').open('a', encoding='utf-8') as fh:
            fh.write(json.dumps(entry, ensure_ascii=False) + '\n')
        if self._suspicious_user_agent() or status in (403, 429, 503):
            SUSPICIOUS_HITS += 1

    def log_message(self, format: str, *args):
        pass

    def end_headers(self):
        self.send_header('Server', 'cloudflare')
        self.send_header('cf-ray', '6d9d93a2-demo-LHR')
        self.send_header('cf-cache-status', 'DYNAMIC')
        self.send_header('X-Powered-By', 'PHP/8.1.14')
        self.send_header('Alt-Svc', 'h3=":443"; ma=86400')
        super().end_headers()

    def _too_fast(self, path: str) -> bool:
        now = time.time()
        bucket = IP_RECENT[self.client_address[0]]
        bucket.append(now)
        while bucket and now - bucket[0] > 8:
            bucket.popleft()
        return path in SENSITIVE_PATHS and len(bucket) > 10

    def _suspicious_user_agent(self) -> bool:
        ua = (self.headers.get('User-Agent') or '').lower()
        return any(token in ua for token in ['python-requests', 'curl', 'wget', 'httpx', 'aiohttp', 'scrapy'])

    def _browser_like_user_agent(self) -> bool:
        ua = (self.headers.get('User-Agent') or '').lower()
        return any(token in ua for token in ['mozilla', 'chrome', 'safari', 'firefox', 'edg']) and not self._suspicious_user_agent()

    def _has_clearance(self) -> bool:
        cookie = self.headers.get('Cookie', '')
        return 'cf_clearance=trainingdemo123' in cookie

    def _serve_json(self, payload, status=200):
        raw = json.dumps(payload, ensure_ascii=False, indent=2).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)
        self._record('GET', urlparse(self.path).path, status)

    def _serve_text(self, payload: str, status=200, content_type='text/plain; charset=utf-8'):
        raw = payload.encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)
        self._record('GET', urlparse(self.path).path, status)

    def _serve_challenge_page(self, target: str):
        safe_target = target if target.startswith('/') else '/index.html'
        html = f"""<!doctype html>
<html lang='en'>
<head>
  <meta charset='utf-8'>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <title>Just a moment...</title>
  <style>
    body {{ margin:0; font-family: Inter, Arial, sans-serif; background:#0b1220; color:#ecf3ff; display:grid; place-items:center; min-height:100vh; }}
    .wrap {{ max-width:720px; padding:32px; border:1px solid rgba(255,255,255,.08); border-radius:24px; background:linear-gradient(180deg,rgba(255,255,255,.04),rgba(255,255,255,.02)); box-shadow:0 20px 70px rgba(0,0,0,.35); }}
    .badge {{ display:inline-block; padding:8px 12px; border-radius:999px; background:rgba(109,211,255,.12); border:1px solid rgba(109,211,255,.25); margin-bottom:12px; }}
    .muted {{ color:#9fb0d2; }}
  </style>
</head>
<body>
  <div class='wrap'>
    <div class='badge'>Checking your browser before accessing Asteria Yield Group</div>
    <h1>Verifying browser integrity</h1>
    <p class='muted'>This local training challenge simulates a JavaScript clearance flow. Browser execution will set a demo clearance cookie and continue to the requested page.</p>
    <p class='muted'>Requested path: <code>{safe_target}</code></p>
    <div id='status'>Challenge in progress...</div>
    <script src='/cdn-cgi/challenge-platform/h/b/orchestrate/jsch/v1?target={quote(safe_target, safe="/%?=&-")}'></script>
  </div>
</body>
</html>"""
        raw = html.encode('utf-8')
        self.send_response(503)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('cf-mitigated', 'challenge')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)
        self._record('GET', target, 503)

    def do_POST(self):
        if self.path.startswith('/api/collect'):
            length = int(self.headers.get('Content-Length', '0'))
            raw = self.rfile.read(length) if length else b''
            try:
                data = json.loads(raw.decode('utf-8')) if raw else {}
            except json.JSONDecodeError:
                data = {'raw': raw.decode('utf-8', errors='replace')}
            data['_remote_addr'] = self.client_address[0]
            data['_received_at'] = now_iso()
            with (LOG_DIR / 'telemetry.jsonl').open('a', encoding='utf-8') as f:
                f.write(json.dumps(data, ensure_ascii=False) + '\n')
            self.send_response(204)
            self.end_headers()
            self._record('POST', '/api/collect', 204)
            return
        self.send_error(404, 'Not Found')
        self._record('POST', urlparse(self.path).path, 404)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path or '/'

        if path == '/pixel.gif':
            self.send_response(200)
            self.send_header('Content-Type', 'image/gif')
            self.send_header('Content-Length', str(len(PIXEL)))
            self.end_headers()
            self.wfile.write(PIXEL)
            self._record('GET', path, 200)
            return

        if path == '/cdn-cgi/trace':
            payload = (
                'fl=29f19\n'
                'h=127.0.0.1\n'
                'ip=127.0.0.1\n'
                f'ts={int(time.time())}\n'
                f'uag={self.headers.get("User-Agent") or "-"}\n'
                'visit_scheme=http\n'
                'colo=LHR\n'
                'http=http/1.1\n'
                'loc=GB\n'
            )
            self._serve_text(payload)
            return

        if path == '/cdn-cgi/challenge-platform/h/b/orchestrate/jsch/v1':
            target = parse_qs(parsed.query).get('target', ['/index.html'])[0]
            js = (
                "document.cookie='cf_clearance=trainingdemo123; path=/';"
                "var el=document.getElementById('status');"
                "if(el){el.textContent='Clearance granted. Redirecting…';}"
                f"setTimeout(function(){{location.href={json.dumps(target)};}},900);"
            )
            self._serve_text(js, content_type='application/javascript; charset=utf-8')
            return

        if path == '/api/briefings':
            self._serve_json(BRIEFINGS)
            return

        if path == '/api/search':
            q = (parse_qs(parsed.query).get('q', [''])[0] or '').strip().lower()
            results = [item for item in SEARCH_INDEX if not q or q in json.dumps(item).lower()]
            self._serve_json({'query': q, 'count': len(results), 'results': results})
            return

        if path == '/api/status':
            payload = {
                'server_time': now_iso(),
                'total_hits': int(sum(PATH_COUNTS.values())),
                'telemetry_events': read_telemetry_count(),
                'suspicious_hits': SUSPICIOUS_HITS,
                'top_paths': [{'path': p, 'count': c} for p, c in PATH_COUNTS.most_common(8)],
                'recent_requests': list(REQUEST_LOG)[:10],
            }
            self._serve_json(payload)
            return

        if path == '/api/portal-snapshot':
            self._serve_json(PORTAL_SNAPSHOT)
            return

        if path.startswith('/trap/'):
            parts = [p for p in path.strip('/').split('/') if p]
            level = int(parts[1]) if len(parts) >= 2 and parts[1].isdigit() else 0
            html = f"<!doctype html><html><head><meta charset='utf-8'><title>Trap {level}</title><style>body{{font-family:Arial,sans-serif;background:#08111f;color:#e8eefc;padding:40px}}a{{color:#6dd3ff}}</style></head><body><h1>Directory depth {level}</h1><p>This is a training crawler trap with branching paths.</p><ul><li><a href='/trap/{level+1}/'>Go deeper</a></li><li><a href='/trap/{level+2}/?src=alt'>Alternate branch</a></li><li><a href='/trap/{level+3}/?chain=tri'>Tertiary branch</a></li><li><a href='/index.html'>Return home</a></li></ul></body></html>"
            raw = html.encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
            self._record('GET', path, 200)
            return

        if self._too_fast(path):
            self.send_response(429)
            self.send_header('Retry-After', '8')
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.end_headers()
            self.wfile.write(b'<html><body><h1>429 Too Many Requests</h1><p>Rate limit engaged for sensitive resource.</p></body></html>')
            self._record('GET', path, 429)
            return

        if path in SENSITIVE_PATHS:
            if self._suspicious_user_agent():
                code = 403 if path == '/admin/staging.html' else 503
                title = '403 Forbidden' if code == 403 else '503 Challenge'
                body = 'Automated access blocked by policy.' if code == 403 else 'Additional browser validation required.'
                self.send_response(code)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                if code == 503:
                    self.send_header('cf-mitigated', 'challenge')
                self.end_headers()
                self.wfile.write(f'<html><body><h1>{title}</h1><p>{body}</p></body></html>'.encode('utf-8'))
                self._record('GET', path, code)
                return
            if self._browser_like_user_agent() and not self._has_clearance():
                self._serve_challenge_page(path)
                return

        if path == '/':
            self.path = '/index.html'

        super().do_GET()
        self._record('GET', urlparse(self.path).path, self._last_response_code)


def main():
    parser = argparse.ArgumentParser(description='Serve the offline mock target locally.')
    parser.add_argument('--port', type=int, default=8765)
    args = parser.parse_args()
    os.chdir(ROOT)
    httpd = ThreadingHTTPServer(('127.0.0.1', args.port), MockTargetHandler)
    print(f'[*] Serving offline mock target on http://127.0.0.1:{args.port}/')
    print('[*] Logs will be written to ./logs/access.log and ./logs/telemetry.jsonl')
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print('\n[!] Stopped.')


if __name__ == '__main__':
    main()
