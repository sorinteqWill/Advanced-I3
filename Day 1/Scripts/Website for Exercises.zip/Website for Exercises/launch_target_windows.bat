@echo off
python start_target.py --port 8765
