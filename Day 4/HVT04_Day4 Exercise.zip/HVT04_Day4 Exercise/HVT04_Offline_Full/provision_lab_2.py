from pathlib import Path
print("[*] Lab 2 provisioning is already included in the packaged data files under data/social and data/geolocation.")
print(f"[*] Working directory: {Path(__file__).resolve().parent}")
