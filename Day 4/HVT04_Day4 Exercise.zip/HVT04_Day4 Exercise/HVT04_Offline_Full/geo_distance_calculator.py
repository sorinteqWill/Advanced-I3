import json, math, csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PATHS = ROOT / "data" / "geolocation" / "sightings.json"
ADV = ROOT / "data" / "advanced_extension" / "geolocation"

def hav(lat1, lon1, lat2, lon2):
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    d1 = math.radians(lat2 - lat1)
    d2 = math.radians(lon2 - lon1)
    a = math.sin(d1/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(d2/2)**2
    return 2 * r * math.asin(math.sqrt(a))

def load_badges(path):
    with open(path, encoding="utf-8") as f:
        return list(csv.DictReader(f))

def main():
    data = json.loads(PATHS.read_text(encoding="utf-8"))
    adv = json.loads((ADV / "route_points.json").read_text(encoding="utf-8"))
    beacons = json.loads((ADV / "beacon_hits.json").read_text(encoding="utf-8"))["beacon_hits"]
    badges = load_badges(ADV / "badge_access_log.csv")
    s = data["suspect_sighting"]
    a = data["associate_sighting"]
    m = data["meeting_point"]
    report = {
        "suspect_to_associate_km": round(hav(s["lat"], s["lon"], a["lat"], a["lon"]), 3),
        "associate_to_meeting_point_km": round(hav(a["lat"], a["lon"], m["lat"], m["lon"]), 3),
        "suspect_to_meeting_point_km": round(hav(s["lat"], s["lon"], m["lat"], m["lon"]), 3),
        "vehicle_plate": adv["vehicle_plate"],
        "route_points": adv["route_points"],
        "beacon_hit_count": len(beacons),
        "badge_access_count": len(badges),
        "last_badge_location": badges[-1]["location"] if badges else "n/a"
    }
    (ROOT / "Geospatial_Correlation.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("[✓] Geospatial correlation complete.")

if __name__ == "__main__":
    main()
