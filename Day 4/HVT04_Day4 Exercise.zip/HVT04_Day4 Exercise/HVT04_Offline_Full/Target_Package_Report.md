# Target Package Report — Operation Pixel Dust

## BLUF
Offline analysis connected the seized imagery, social overlap data, badge/access telemetry, and geospatial points into a coherent event chain centered on Pier 17.

## Evidence handling
- Triaged artefacts copied: 21
- Advanced dataset and supplemental resources were enabled automatically.

## OCR / local vision findings
- **courtyard_shadow.jpg**: South Arcade Courtyard
- **locker_seed_card.jpg**: L-442, Quayside East
- **meeting_notice.png**: Pier 17, 21:15, signal-safe-room
- **receipt_fragment.jpg**: Cafe Delta, 17:42, QY-8841, marina_ops_guest
- **vehicle_board.png**: BX14 KRM, North Lock, Pier 17, KESTREL-4, 21:00-21:20
- **dock_access_badge.jpg**: 4418, M.ARLEN, North Lock Gate, Pier 17 Service Door
- **pier17_route_board.png**: PIER 17, BX14 KRM, KESTREL-4, Blue Satchel
- **terminal_chat_capture.png**: harborfox, marlin-ops, quayshade, northlock-admin, 4418

## Social overlap
- Overlapping aliases identified: 7
- `delta_table6` across [b,c,d] on signal,telegram,x
- `harborfox` across [a,d] on mastodon,telegram
- `kestrel4` across [a,b,c] on discord,signal,telegram
- `marlin-ops` across [a,b,d] on discord,telegram
- `nightferry` across [a,b] on signal,telegram
- `northlock-admin` across [c,d] on discord,signal
- `quayshade` across [a,b,d] on instagram,signal,x

## Geospatial correlation
- Suspect to associate separation: 0.11 km
- Associate to meeting point separation: 0.075 km
- Vehicle plate surfaced in advanced data: BX14 KRM
- Badge events observed: 4

## Chronolocation
- Computed solar elevation: 29.96°
- Best-fit local time from lookup table: 15:20
- Claimed time in evidence metadata: 2026-03-18T14:35:00

## Timeline correlation
- Correlated event count: 9
- Key inference: Badge 4418, device beacon movement, and corrected camera time converge on a service-door arrival immediately before the Pier 17 meeting window.

## Assessment
- Multiple independent lines of analysis converge on a coordinated logistics event involving Pier 17, Quayside East, North Lock, and the KESTREL-4 / marlin-ops network.
- Badge 4418 and the corrected Pier 17 camera timing significantly strengthen the movement narrative.
- The package should be used as an intelligence product and paired with additional evidential validation where required.
