# HVT04 Day 4 — Expanded Start Command Auto-Run Edition

Default command:

```bash
python3 lab_manager.py start
```

That single command now does all of the following automatically:
- starts the local Day 4 lab portal
- starts the local scoreboard
- clears prior run artefacts
- runs the full Day 4 offline evidence pipeline
- stages and uses the advanced dataset automatically
- pulls in the expanded resource pack automatically
- generates the target package, chronolocation output, OCR triage, network linkage, timeline correlation, and evidence manifest

Optional commands:
- `python3 lab_manager.py start-services` — start only the local services without auto-running the pipeline
- `python3 lab_manager.py show` — print URLs and artefact locations
- `python3 lab_manager.py stop` — stop the local lab services

Primary outputs:
- `forensic_vault/`
- `OCR_Triage_Report.json`
- `Social_Link_Analysis.csv`
- `Chronolocation_Report.json`
- `Geospatial_Correlation.json`
- `Timeline_Correlation.json`
- `AI_Target_Summary.txt`
- `Target_Package_Report.md`
- `evidence_manifest.txt`

Extra resources are documented in:
- `docs/DAY4_RESOURCE_GUIDE.md`
- `instructor_answer_key/DAY4_WALKTHROUGH_EXPANDED.md`
