import json
import os
import shutil
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ENV_FILE = ROOT / ".lab_env.json"
PIDS_FILE = ROOT / ".lab_pids.json"
PIPELINE_STEPS = [
    "rapid_triager.py",
    "local_vision_triage.py",
    "social_linker.py",
    "geo_distance_calculator.py",
    "shadow_calculator.py",
    "timeline_correlator.py",
    "local_ai_chat.py",
    "report_generator.py",
    "evidence_sealer.py",
]

def find_free_port(start=8040):
    port = start
    while True:
        with socket.socket() as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                port += 1

def stop_lab(silent=False):
    if PIDS_FILE.exists():
        try:
            pids = json.loads(PIDS_FILE.read_text(encoding="utf-8"))
        except Exception:
            pids = []
        for pid in pids:
            try:
                os.kill(pid, signal.SIGTERM)
            except Exception:
                pass
        try:
            PIDS_FILE.unlink()
        except Exception:
            pass
    if not silent:
        print("[*] Lab services stopped.")

def clean_previous_outputs():
    paths = [
        ROOT / "forensic_vault",
        ROOT / "Triager_Inventory.json",
        ROOT / "OCR_Triage_Report.json",
        ROOT / "OCR_Triage_Report.txt",
        ROOT / "Social_Link_Analysis.csv",
        ROOT / "Social_Link_Analysis.json",
        ROOT / "Chronolocation_Report.json",
        ROOT / "Geospatial_Correlation.json",
        ROOT / "Timeline_Correlation.json",
        ROOT / "AI_Target_Summary.txt",
        ROOT / "Target_Package_Report.md",
        ROOT / "evidence_manifest.txt",
    ]
    for path in paths:
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
        elif path.exists():
            try:
                path.unlink()
            except Exception:
                pass
    (ROOT / "forensic_vault").mkdir(exist_ok=True)

def run_default_pipeline():
    print("[*] Running default Day 4 evidence pipeline...")
    code = 0
    for step in PIPELINE_STEPS:
        print(f"    -> {step}")
        rc = subprocess.call([sys.executable, str(ROOT / step)], cwd=ROOT)
        code = code or rc
        if rc != 0:
            print(f"[-] Step failed: {step} (exit {rc})")
            break
    if code == 0:
        print("[✓] Expanded Day 4 pipeline completed. Advanced dataset and supplemental resources were used automatically.")
    return code

def start_lab(run_pipeline=True):
    stop_lab(silent=True)
    clean_previous_outputs()
    target_port = find_free_port(8040)
    score_port = find_free_port(target_port + 1)
    p1 = subprocess.Popen([sys.executable, str(ROOT / "target_server.py"), "--port", str(target_port)],
                          cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    p2 = subprocess.Popen([sys.executable, "-m", "http.server", str(score_port), "--directory", str(ROOT / "scoreboard")],
                          cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(1.0)
    profile_path = ROOT / "data" / "lab_profile.json"
    profile = json.loads(profile_path.read_text(encoding="utf-8"))
    profile["base_url"] = f"http://127.0.0.1:{target_port}"
    profile_path.write_text(json.dumps(profile, indent=2), encoding="utf-8")
    ENV_FILE.write_text(json.dumps({"target_url": profile["base_url"], "scoreboard_url": f"http://127.0.0.1:{score_port}"}, indent=2), encoding="utf-8")
    PIDS_FILE.write_text(json.dumps([p1.pid, p2.pid], indent=2), encoding="utf-8")
    print("[✓] HVT04 lab started.")
    if run_pipeline:
        rc = run_default_pipeline()
        if rc != 0:
            print("[-] The lab started, but the automation pipeline did not complete cleanly.")
    show_lab()

def show_lab():
    if not ENV_FILE.exists():
        print("[-] Lab not started yet.")
        return
    env = json.loads(ENV_FILE.read_text(encoding="utf-8"))
    print(f"[*] Target URL: {env['target_url']}/portal")
    print(f"[*] Scoreboard: {env['scoreboard_url']}")
    print("[*] Primary outputs: OCR_Triage_Report.*, Social_Link_Analysis.*, Chronolocation_Report.json, Geospatial_Correlation.json, Timeline_Correlation.json, AI_Target_Summary.txt, Target_Package_Report.md, evidence_manifest.txt")

def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "show"
    if cmd == "start":
        start_lab(run_pipeline=True)
    elif cmd == "start-services":
        start_lab(run_pipeline=False)
    elif cmd == "stop":
        stop_lab()
    elif cmd == "show":
        show_lab()
    else:
        print("Usage: python lab_manager.py [start|start-services|stop|show]")

if __name__ == "__main__":
    main()
