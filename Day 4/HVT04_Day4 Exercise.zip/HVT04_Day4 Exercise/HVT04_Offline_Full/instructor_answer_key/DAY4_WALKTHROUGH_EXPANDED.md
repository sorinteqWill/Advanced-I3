# Day 4 expanded instructor walkthrough

## Key answer themes
- Badge **4418** is a strong bridge between the visual artefacts, the badge log, and the service-door event.
- **M.ARLEN** appears as the operator hint in the badge log and should be treated as a lead, not proof of sole responsibility.
- The route sequence should resolve as:
  1. Cafe Delta
  2. North Lock
  3. Pier 17
- `camera_time_offsets.json` means students should correct the visible Pier 17 time by **93 seconds**.
- The expanded social dataset should increase the overlap count and surface additional roles:
  - `harborfox`
  - `marlin-ops`
  - `quayshade`
  - `kestrel4`
  - `delta_table6`
- The operational narrative should show coordinated logistics, not an isolated meetup.

## Good student output
A good answer should mention:
- the evidence is convergent across image OCR, social links, badge access, beacon hits, and route points
- the meeting window is consistent with a staged logistics transfer
- the satchel, vehicle, and service-door access create a stronger prosecution/intelligence package than any one artefact alone
