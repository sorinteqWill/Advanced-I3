# Operation Pixel Dust — Instructor answer key

Expected primary findings:
- Chronolocation estimate is much closer to **14:35** than to morning alternatives because `atan(1.85 / 3.21)` produces an elevation of about 29.95 degrees, closest to the lookup row near **15:20 (30.2°)** and still materially inconsistent with midday assumptions. It supports an afternoon capture window rather than a claimed manipulated narrative if students alter the scenario.
- OCR / local vision triage should recover:
  - `L-442`
  - `Quayside East`
  - `Pier 17`
  - `21:15`
  - `signal-safe-room`
  - advanced add-on values such as `BX14 KRM`, `KESTREL-4`, `QY-8841`, `marina_ops_guest`
- Social overlap should identify at minimum:
  - `quayshade`
  - `marlin-ops`
  - `kestrel4`
  - `nightferry`
- Geospatial correlation should show the suspect and associate sightings are within a short walking distance shortly before the `Pier 17` meeting point.
- The final report should tie the visual, temporal, and network findings together.
