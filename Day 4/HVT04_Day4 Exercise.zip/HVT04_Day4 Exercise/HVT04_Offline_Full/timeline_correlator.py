import csv
import json
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ADV = ROOT / "data" / "advanced_extension"

def parse_ts(value):
    return datetime.fromisoformat(value)

def load_csv(path):
    with open(path, encoding="utf-8") as f:
        return list(csv.DictReader(f))

def main():
    badge_rows = load_csv(ADV / "geolocation" / "badge_access_log.csv")
    beacons = json.loads((ADV / "geolocation" / "beacon_hits.json").read_text(encoding="utf-8"))["beacon_hits"]
    offsets = json.loads((ADV / "geolocation" / "camera_time_offsets.json").read_text(encoding="utf-8"))["offsets"]
    manifest = json.loads((ROOT / "data" / "casefiles" / "case_manifest.json").read_text(encoding="utf-8"))

    corrected = []
    for item in offsets:
        displayed = datetime.fromisoformat("2026-03-18T" + item["displayed_time"])
        corrected_time = displayed + timedelta(seconds=item["verified_offset_seconds"])
        corrected.append({
            "camera": item["camera"],
            "displayed_time": item["displayed_time"],
            "corrected_time": corrected_time.time().isoformat(timespec="seconds"),
            "offset_seconds": item["verified_offset_seconds"]
        })

    timeline = []
    for row in badge_rows:
        timeline.append({"time": row["timestamp"], "type": "badge", "detail": f"{row['location']} / {row['result']} / {row['badge_id']}"})
    for row in beacons:
        timeline.append({"time": row["time"], "type": "beacon", "detail": row["label"]})
    for item in corrected:
        timeline.append({"time": "2026-03-18T" + item["corrected_time"], "type": "camera", "detail": f"{item['camera']} corrected"})
    timeline = sorted(timeline, key=lambda x: x["time"])

    report = {
        "camera_corrections": corrected,
        "ordered_timeline": timeline,
        "key_inference": "Badge 4418, device beacon movement, and corrected camera time converge on a service-door arrival immediately before the Pier 17 meeting window.",
        "supporting_entities": sorted({ent for section in ("advanced_images", "supplemental_images") for item in manifest.get(section, []) for ent in item.get("entities", [])})
    }
    (ROOT / "Timeline_Correlation.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("[✓] Timeline correlation generated.")

if __name__ == "__main__":
    main()
