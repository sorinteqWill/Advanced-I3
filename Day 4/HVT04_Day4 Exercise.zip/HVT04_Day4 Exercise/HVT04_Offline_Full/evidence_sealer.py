import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TARGETS = [
    "OCR_Triage_Report.json",
    "OCR_Triage_Report.txt",
    "Social_Link_Analysis.csv",
    "Social_Link_Analysis.json",
    "Chronolocation_Report.json",
    "Geospatial_Correlation.json",
    "Timeline_Correlation.json",
    "AI_Target_Summary.txt",
    "Target_Package_Report.md",
]

def sha256(path: Path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

def main():
    lines = []
    for name in TARGETS:
        p = ROOT / name
        if p.exists():
            lines.append(f"{name}\t{sha256(p)}")
    for p in sorted((ROOT / "forensic_vault").glob("*")):
        if p.is_file():
            lines.append(f"forensic_vault/{p.name}\t{sha256(p)}")
    (ROOT / "evidence_manifest.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"[✓] Evidence manifest generated with {len(lines)} entries.")

if __name__ == "__main__":
    main()
