import argparse
import json
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"

class Handler(BaseHTTPRequestHandler):
    def _send(self, body, content_type="text/html; charset=utf-8", status=200):
        body = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path in ("/", "/portal"):
            self._send(f'''
            <html><body style="font-family:Arial;background:#222;color:#eee;padding:24px">
            <h1>Operation Pixel Dust</h1>
            <p>Local Day 4 evidence portal.</p>
            <ul>
              <li><a href="/evidence" style="color:#9cf">Evidence index</a></li>
              <li><a href="/download/meeting_notice.png" style="color:#9cf">meeting_notice.png</a></li>
              <li><a href="/download/locker_seed_card.jpg" style="color:#9cf">locker_seed_card.jpg</a></li>
              <li><a href="/download/dock_access_badge.jpg" style="color:#9cf">dock_access_badge.jpg</a></li>
              <li><a href="/download/pier17_route_board.png" style="color:#9cf">pier17_route_board.png</a></li>
              <li><a href="/download/terminal_chat_capture.png" style="color:#9cf">terminal_chat_capture.png</a></li>
            </ul>
            </body></html>
            ''')
            return
        if self.path == "/evidence":
            manifest = json.loads((DATA / "casefiles" / "case_manifest.json").read_text(encoding="utf-8"))
            items = []
            for section in ("images", "advanced_images", "supplemental_images"):
                for item in manifest.get(section, []):
                    suffix = " [advanced]" if section != "images" else ""
                    items.append(f"<li>{item['file']} — {item['notes']}{suffix}</li>")
            body = "<html><body style='font-family:Arial;background:#222;color:#eee;padding:24px'><h2>Evidence Index</h2><ul>" + "".join(items) + "</ul></body></html>"
            self._send(body)
            return
        if self.path.startswith("/download/"):
            name = unquote(self.path.split("/download/",1)[1])
            for base in [DATA/"images", DATA/"advanced_extension"/"images"]:
                p = base / name
                if p.exists():
                    self._send(p.read_bytes(), content_type="application/octet-stream")
                    return
            self._send("Not found", status=404)
            return
        self._send("Not found", status=404)

    def log_message(self, fmt, *args):
        pass

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8040)
    args = ap.parse_args()
    HTTPServer(("127.0.0.1", args.port), Handler).serve_forever()
