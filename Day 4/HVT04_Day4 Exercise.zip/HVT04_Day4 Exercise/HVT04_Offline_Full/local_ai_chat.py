import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def load_json(name):
    p = ROOT / name
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}

def main():
    ocr = load_json("OCR_Triage_Report.json")
    geo = load_json("Geospatial_Correlation.json")
    chrono = load_json("Chronolocation_Report.json")
    social = load_json("Social_Link_Analysis.json")
    timeline = load_json("Timeline_Correlation.json")
    entities = []
    for item in ocr.get("findings", []):
        entities.extend(item.get("entities", []))
    entities = sorted(set(entities))

    lines = [
        "Operation Pixel Dust — Offline AI Analytical Summary",
        "",
        "Confidence indicators:",
        f"- OCR / local vision surfaced {len(entities)} distinct entities.",
        f"- Social overlap count: {len(social)} aliases.",
        f"- Suspect to associate separation: {geo.get('suspect_to_associate_km', 'n/a')} km.",
        f"- Chronolocation best fit: {chrono.get('best_candidate_time_local', 'n/a')} local.",
        f"- Timeline events correlated: {len(timeline.get('ordered_timeline', []))}.",
        "",
        "Narrative synthesis:",
        "- The expanded artefact pack aligns around Pier 17, North Lock, badge 4418, and a coordinated service-door approach.",
        "- The overlapping aliases strengthen the relationship between the suspect ecosystem and logistics coordination accounts.",
        "- The geospatial output places suspect and associate devices within short proximity before the declared meeting point.",
        "- The timeline correlation supports a deliberate transit chain from Cafe Delta to North Lock to Pier 17.",
        "- The chronolocation calculation provides an objective time estimate grounded in shadow geometry rather than the uploader claim.",
        "",
        "Priority extracted entities:",
        ", ".join(entities) if entities else "No entities extracted."
    ]
    (ROOT / "AI_Target_Summary.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("[✓] Offline AI summary generated.")

if __name__ == "__main__":
    main()
