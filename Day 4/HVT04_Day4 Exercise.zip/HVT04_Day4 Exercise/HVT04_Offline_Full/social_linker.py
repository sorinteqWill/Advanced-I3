import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOCIAL = ROOT / "data" / "social"
ADV = ROOT / "data" / "advanced_extension" / "social"

def load_rows(path):
    rows = []
    with open(path, encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(row)
    return rows

def main():
    datasets = {
        "a": load_rows(SOCIAL / "suspect_followers_a.csv"),
        "b": load_rows(SOCIAL / "suspect_followers_b.csv"),
        "c": load_rows(ADV / "suspect_followers_c.csv"),
        "d": load_rows(ADV / "suspect_followers_d.csv"),
    }
    posts = json.loads((ADV / "social_posts_summary.json").read_text(encoding="utf-8"))["posts"]

    alias_maps = {key: {r["alias"]: r for r in rows} for key, rows in datasets.items()}
    all_aliases = sorted(set().union(*[set(m.keys()) for m in alias_maps.values()]))

    enriched = []
    for alias in all_aliases:
        presence = [key for key, amap in alias_maps.items() if alias in amap]
        if len(presence) >= 2:
            post_hits = [p for p in posts if p["alias"] == alias]
            enriched.append({
                "alias": alias,
                "present_in": ",".join(sorted(presence)),
                "platforms": ",".join(sorted({alias_maps[k][alias]["platform"] for k in presence})),
                "latest_seen": max(
                    [alias_maps[k][alias].get("last_seen", "") for k in presence] + [p["timestamp"] for p in post_hits]
                ),
                "note": " | ".join(filter(None, [alias_maps[k][alias].get("note", "") for k in presence] + [p.get("tag", "") for p in post_hits])),
                "post_count": len(post_hits)
            })

    with open(ROOT / "Social_Link_Analysis.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["alias", "present_in", "platforms", "latest_seen", "post_count", "note"])
        w.writeheader()
        w.writerows(enriched)
    (ROOT / "Social_Link_Analysis.json").write_text(json.dumps(enriched, indent=2), encoding="utf-8")
    print(f"[✓] Social linker identified {len(enriched)} overlapping aliases across expanded datasets.")

if __name__ == "__main__":
    main()
