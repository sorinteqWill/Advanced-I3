import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "data" / "casefiles" / "case_manifest.json"

def main():
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    findings = []
    for section in ("images", "advanced_images", "supplemental_images"):
        for item in manifest.get(section, []):
            findings.append({
                "file": item["file"],
                "ocr_text": item.get("ocr_text", []),
                "entities": item.get("entities", []),
                "priority": item.get("priority", "medium"),
                "notes": item.get("notes", ""),
                "section": section
            })
    out = {"case": "Operation Pixel Dust", "findings": findings}
    (ROOT / "OCR_Triage_Report.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    lines = ["Operation Pixel Dust — OCR / Local Vision Triage", ""]
    for item in findings:
        lines.append(f"- {item['file']} ({item['section']}): " + "; ".join(item["entities"] or item["ocr_text"]))
    (ROOT / "OCR_Triage_Report.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"[✓] Local vision triage completed for {len(findings)} images.")

if __name__ == "__main__":
    main()
