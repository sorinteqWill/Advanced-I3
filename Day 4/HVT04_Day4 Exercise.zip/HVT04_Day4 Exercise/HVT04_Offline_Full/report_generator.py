import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def load_json(name):
    p = ROOT / name
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}

def main():
    ocr = load_json("OCR_Triage_Report.json")
    geo = load_json("Geospatial_Correlation.json")
    chrono = load_json("Chronolocation_Report.json")
    social = load_json("Social_Link_Analysis.json")
    triager = load_json("Triager_Inventory.json")
    timeline = load_json("Timeline_Correlation.json")

    lines = [
        "# Target Package Report — Operation Pixel Dust",
        "",
        "## BLUF",
        "Offline analysis connected the seized imagery, social overlap data, badge/access telemetry, and geospatial points into a coherent event chain centered on Pier 17.",
        "",
        "## Evidence handling",
        f"- Triaged artefacts copied: {len(triager.get('copied_files', []))}",
        "- Advanced dataset and supplemental resources were enabled automatically.",
        "",
        "## OCR / local vision findings",
    ]
    for item in ocr.get("findings", []):
        lines.append(f"- **{item['file']}**: " + ", ".join(item.get("entities", []) or item.get("ocr_text", [])))
    lines += [
        "",
        "## Social overlap",
        f"- Overlapping aliases identified: {len(social)}",
    ]
    for row in social:
        lines.append(f"- `{row['alias']}` across [{row['present_in']}] on {row['platforms']}")
    lines += [
        "",
        "## Geospatial correlation",
        f"- Suspect to associate separation: {geo.get('suspect_to_associate_km', 'n/a')} km",
        f"- Associate to meeting point separation: {geo.get('associate_to_meeting_point_km', 'n/a')} km",
        f"- Vehicle plate surfaced in advanced data: {geo.get('vehicle_plate', 'n/a')}",
        f"- Badge events observed: {geo.get('badge_access_count', 'n/a')}",
        "",
        "## Chronolocation",
        f"- Computed solar elevation: {chrono.get('computed_solar_elevation_deg', 'n/a')}°",
        f"- Best-fit local time from lookup table: {chrono.get('best_candidate_time_local', 'n/a')}",
        f"- Claimed time in evidence metadata: {chrono.get('claimed_time_local', 'n/a')}",
        "",
        "## Timeline correlation",
        f"- Correlated event count: {len(timeline.get('ordered_timeline', []))}",
        f"- Key inference: {timeline.get('key_inference', 'n/a')}",
        "",
        "## Assessment",
        "- Multiple independent lines of analysis converge on a coordinated logistics event involving Pier 17, Quayside East, North Lock, and the KESTREL-4 / marlin-ops network.",
        "- Badge 4418 and the corrected Pier 17 camera timing significantly strengthen the movement narrative.",
        "- The package should be used as an intelligence product and paired with additional evidential validation where required.",
        ""
    ]
    (ROOT / "Target_Package_Report.md").write_text("\n".join(lines), encoding="utf-8")
    print("[✓] Target package report written.")

if __name__ == "__main__":
    main()
