import json, math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MEASURE = ROOT / "data" / "geolocation" / "shadow_measurements.json"

def main():
    data = json.loads(MEASURE.read_text(encoding="utf-8"))
    elev = math.degrees(math.atan(data["object_height_m"] / data["shadow_length_m"]))
    best = min(data["candidate_times_local"], key=lambda x: abs(x["sun_elevation_deg"] - elev))
    report = {
        "computed_solar_elevation_deg": round(elev, 2),
        "best_candidate_time_local": best["time"],
        "best_candidate_elevation_deg": best["sun_elevation_deg"],
        "claimed_time_local": data["claimed_time_local"],
        "delta_from_claimed_elevation_deg": round(abs(best["sun_elevation_deg"] - elev), 2),
        "note": "Lookup-table method for deterministic offline lab use."
    }
    (ROOT / "Chronolocation_Report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("[✓] Shadow calculation completed.")

if __name__ == "__main__":
    main()
