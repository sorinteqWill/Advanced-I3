import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VAULT = ROOT / "forensic_vault"
DATA = ROOT / "data"

HIGH_VALUE_EXTS = {".jpg", ".jpeg", ".png", ".csv", ".json", ".txt", ".md"}

def copy_if_interesting(path: Path):
    if path.suffix.lower() in HIGH_VALUE_EXTS:
        dest = VAULT / path.name
        shutil.copy2(path, dest)
        return str(dest.name)
    return None

def main():
    VAULT.mkdir(exist_ok=True)
    copied = []
    bases = [
        DATA / "images",
        DATA / "social",
        DATA / "geolocation",
        DATA / "casefiles",
        DATA / "advanced_extension" / "images",
        DATA / "advanced_extension" / "social",
        DATA / "advanced_extension" / "geolocation",
        DATA / "advanced_extension" / "casefiles",
    ]
    for base in bases:
        for p in sorted(base.glob("*")):
            if p.is_file():
                hit = copy_if_interesting(p)
                if hit:
                    copied.append(hit)
    (ROOT / "Triager_Inventory.json").write_text(json.dumps({"copied_files": copied}, indent=2), encoding="utf-8")
    print(f"[✓] Rapid triage copied {len(copied)} artefacts into forensic_vault/")

if __name__ == "__main__":
    main()
