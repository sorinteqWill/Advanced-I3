# Day 4 quick use

Start everything:
```bash
python3 lab_manager.py start
```

Services only:
```bash
python3 lab_manager.py start-services
```

The portal will expose:
- `/portal`
- `/evidence`
- `/download/<file>`

Outputs are placed in the root folder and in `forensic_vault/`.

Expanded files now include:
- additional image artefacts
- badge access logs
- beacon hits
- camera clock offsets
- an extra social dataset and post summary
- instructor and student resource guides
