# Day 4 additional resource guide

This expanded pack adds more depth to the investigation.

## New resources
- `data/advanced_extension/images/dock_access_badge.jpg`
- `data/advanced_extension/images/pier17_route_board.png`
- `data/advanced_extension/images/terminal_chat_capture.png`
- `data/advanced_extension/social/suspect_followers_d.csv`
- `data/advanced_extension/social/social_posts_summary.json`
- `data/advanced_extension/geolocation/badge_access_log.csv`
- `data/advanced_extension/geolocation/beacon_hits.json`
- `data/advanced_extension/geolocation/camera_time_offsets.json`
- `data/advanced_extension/casefiles/supplemental_case_notes.json`

## What students should do
1. Run `python3 lab_manager.py start`
2. Review `OCR_Triage_Report.json` for newly surfaced entities.
3. Compare `Timeline_Correlation.json` against the claimed event sequence.
4. Use `Geospatial_Correlation.json` to validate movement from Cafe Delta to North Lock to Pier 17.
5. Use `Social_Link_Analysis.csv` and `social_posts_summary.json` to identify the coordination roles.
6. Build a short intelligence assessment tying badge 4418, BX14 KRM, KESTREL-4, and the blue satchel together.

## Instructor steer
Prompt students to reconcile any visible timestamp with the camera offset file before making conclusions.
