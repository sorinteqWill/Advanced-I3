import json
import shutil
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROFILE_PATH = ROOT / 'data' / 'lab_profile.json'
ADV_ROOT = ROOT / 'data' / 'advanced_extension'


def load_profile():
    return json.loads(PROFILE_PATH.read_text(encoding='utf-8'))


def fetch_json(url):
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=20) as resp:
        return json.loads(resp.read().decode('utf-8'))


def stage_advanced_files(vault: Path):
    staged = []
    target_dir = vault / 'advanced_auto'
    target_dir.mkdir(parents=True, exist_ok=True)
    wanted = [
        ADV_ROOT / 'http_api' / 'mock_har_capture.har',
        ADV_ROOT / 'http_api' / 'graphql_schema.json',
        ADV_ROOT / 'http_api' / 'rest_endpoints.json',
        ADV_ROOT / 'http_api' / 'websocket_frames.jsonl',
        ADV_ROOT / 'auth' / 'session_cookies.json',
        ADV_ROOT / 'auth' / 'refresh_token_log.json',
        ADV_ROOT / 'auth' / 'jwt_samples.txt',
        ADV_ROOT / 'logs' / 'nginx_access.log',
        ADV_ROOT / 'logs' / 'auth_audit.log',
        ADV_ROOT / 'logs' / 'app_errors.log',
        ADV_ROOT / 'logs' / 'reverse_proxy_headers.log',
        ADV_ROOT / 'identity' / 'email_aliases.json',
        ADV_ROOT / 'identity' / 'username_reuse.csv',
        ADV_ROOT / 'finance' / 'payments.csv',
        ADV_ROOT / 'finance' / 'wallets.csv',
        ADV_ROOT / 'finance' / 'payout_requests.json',
        ADV_ROOT / 'timeline' / 'master_event_timeline_seed.json',
        ADV_ROOT / 'timeline' / 'mixed_timestamps.csv',
        ADV_ROOT / 'timeline' / 'time_normalization_cases.json',
        ADV_ROOT / 'deceptions' / 'seeded_false_leads.json',
    ]
    for src in wanted:
        if src.exists():
            dst = target_dir / src.name
            shutil.copy2(src, dst)
            staged.append(dst.name)
    return staged


def recover():
    profile = load_profile()
    vault = ROOT / 'forensic_vault'
    vault.mkdir(exist_ok=True)
    trace_path = vault / 'network_trace.json'
    if trace_path.exists():
        trace = json.loads(trace_path.read_text(encoding='utf-8'))
    else:
        base = profile.get('base_url', 'http://127.0.0.1:8030').rstrip('/')
        trace = fetch_json(base + '/api/mock-devtools/network-trace')
        trace_path.write_text(json.dumps(trace, indent=2), encoding='utf-8')

    recovered = []
    for req in trace.get('requests', []):
        headers = req.get('headers', {})
        token = headers.get('Authorization')
        if token:
            recovered.append((req.get('url', ''), token))

    if not recovered:
        print('[-] No Authorization tokens recovered from trace.')
        return 1

    token_file = ROOT / 'Recovered_Discord_Token.txt'
    path_file = ROOT / 'Recovered_API_Paths.txt'
    token_file.write_text(recovered[0][1] + '\n', encoding='utf-8')
    path_file.write_text('\n'.join(url for url, _ in recovered) + '\n', encoding='utf-8')

    staged = stage_advanced_files(vault)
    print('[✓] Authorization token recovered from simulated network trace.')
    print(f'[*] Token saved to: {token_file.name}')
    print(f'[*] API path saved to: {path_file.name}')
    if staged:
        print(f'[*] Advanced artefacts auto-staged: {len(staged)} files into forensic_vault/advanced_auto')
    return 0


if __name__ == '__main__':
    raise SystemExit(recover())
