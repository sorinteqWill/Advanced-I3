(function(){
const BOOT = {
  render: "/api/render?scene=ghost-portal-v3",
  trace: "/api/mock-devtools/network-trace",
  assets: "/api/assets/manifest"
};
window.__APP_BOOT__ = BOOT;
async function boot(){
  const [renderRes, assetRes] = await Promise.all([fetch(BOOT.render), fetch(BOOT.assets)]);
  const data = await renderRes.json();
  const assets = await assetRes.json();
  const app = document.getElementById("app");
  app.innerHTML = `
    <div class="grid">
      <div class="card"><h3>${data.portal_name}</h3><p>${data.tagline}</p><div class="small">Tracking ID: ${data.tracking_id}</div><div class="small">Tag Manager: ${data.tag_manager_id}</div></div>
      <div class="card"><h3>Research Drop</h3><ul>${data.links.map(x => `<li><a href="${x.href}" style="color:#93c5fd">${x.label}</a></li>`).join('')}</ul></div>
      <div class="card"><h3>Operations Notes</h3><p>Telegram: <code>${data.telegram_handle}</code></p><p>Discord channel: <code>${data.discord_channel_id}</code></p><p class="small">${data.portal_admin_hint}</p></div>
      <div class="card"><h3>Visible Tags</h3><p>${assets.visible_tags.join(' | ')}</p><p class="small">Campaign: ${assets.campaign}</p></div>
    </div>`;
}
boot();
})();