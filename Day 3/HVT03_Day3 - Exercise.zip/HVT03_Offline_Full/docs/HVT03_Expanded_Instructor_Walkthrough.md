# HVT03 Expanded Instructor Walkthrough

## Lab intent
This exercise expands the original Day 3 headless-rendering and dark-social workflow. Students must correlate values across:
- a JavaScript-rendered portal
- a simulated DevTools network trace
- a Telegram-style message export
- a Discord-style message export

## Step-by-step
1. Start the target environment with `lab_manager.py start`.
2. Confirm the target URL with `lab_manager.py show`.
3. Run `headless_infiltrator.py`.
   - Students should recover:
     - Tracking ID: `G-9X7LAB-V3`
     - Tag Manager ID: `GTM-7Q4LAB2`
     - Telegram handle: `@phantom_ops_public`
     - Discord channel ID: `112233445566778899`
     - Admin hint: `phoenix.qa@asterion-advisory.local`
4. Run `network_trace_recover.py`.
   - Students should recover:
     - Authorization header: `Bearer LAB_UCO_TOKEN_DAY3_RED_V3`
     - Discord API path containing the real channel ID
5. Run `tg_channel_dumper.py`.
   - Students should create both CSV and JSON channel archives.
6. Run `discord_infiltrator.py`.
   - Students should create both CSV and JSON channel archives.
7. Run `threat_intel_parser.py`.
   - Students should produce:
     - `Extracted_IOC_Report.txt`
     - `Extracted_IOC_Report.json`
     - `IOC_Target_Matrix.csv`
8. Run `evidence_sealer.py`.
   - Students should produce `evidence_manifest.txt`.

## Key expected pivots
- Primary alias: `darkquill_47`
- Secondary alias: `vault_owl`
- BTC wallets:
  - `bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh`
  - `3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy`
- Monero wallets:
  - `4A9ov9JcLrTuB8HCP7jM18QwGhkeDPJqsCoJ65qTSR3iEyFZBBQfquLj79xuckwDiJvY36k7ctGHnZxMuisZ3YNcpjj6icX`
  - `4ADkndLnPrUcpAyoqPJX7HwbwKkKyYKbouQJfMFrNvzazmhh1BwCXSd5v9SMW9hAu6wBHxsLrKX5J3X9PQ8uYGAW2FYzYHz`
- Onion mirrors:
  - `f4j6k2l9h3r5t7y2.onion`
  - `relayarchiveopsx6r2m4v7h9k3p5d8q2w4e6t8y0u1i3o5p7a9s.onion`
- Infrastructure nodes:
  - `198.51.100.44`
  - `203.0.113.27`
  - `192.0.2.63`
  - `10.66.5.15:8080`
  - `172.22.13.26:8443`

## Instructor notes
- The raw HTML contains a decoy handle. Students must go through the app bundle and render API to get the real values.
- The Discord authorization token is not in the rendered page. It is only exposed through the simulated DevTools network trace.
- The datasets intentionally contain overlap, repetition, and noise. Students should be assessed on correlation, not just collection.

## Troubleshooting
- If Telegram auth fails, delete `UCO_Session.session` and retry with `24680`.
- If Discord returns unauthorized, confirm `Recovered_Discord_Token.txt` exists and starts with `Bearer`.
- If the lab will not start, move the bundle outside synced folders and rerun from a local path.
