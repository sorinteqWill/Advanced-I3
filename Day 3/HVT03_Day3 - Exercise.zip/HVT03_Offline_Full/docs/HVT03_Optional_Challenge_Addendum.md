# HVT03 Optional Challenge Addendum

For stronger students or a longer delivery window, add one or more of these extensions:

## Challenge 1 - Cross-source overlap
Use `IOC_Target_Matrix.csv` to identify the top 5 IOCs appearing in the highest number of source files.

## Challenge 2 - Timeline reconstruction
Build a short timeline of activity using:
- `TG_Archive_phantom_ops_public.csv`
- `Discord_Archive_112233445566778899.csv`

## Challenge 3 - Priority lead selection
From the discovered IOCs, select:
- one wallet
- one infrastructure node
- one account alias
- one email
Explain which should be actioned first and why.

## Challenge 4 - Reporting drill
Write a 1-page tactical summary for an SIO explaining why:
- the rendered portal values matter
- the Authorization token mattered
- the cross-platform IOC overlap raises confidence
