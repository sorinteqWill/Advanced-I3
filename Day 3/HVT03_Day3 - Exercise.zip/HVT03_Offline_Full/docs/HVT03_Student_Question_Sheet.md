# HVT03 Student Question Sheet

1. What values were recoverable only after JavaScript rendering?
2. What value was recoverable only from the simulated network trace?
3. Which IOCs overlap across both Telegram and Discord?
4. Which wallet(s) appear in multiple sources?
5. Which infrastructure node would you prioritize for follow-on Day 2 pivoting, and why?
6. What evidence would you include in a CPS-facing report to justify a production order or warrant?
7. Which outputs should be hashed before dissemination?
8. Which data points are intelligence leads versus direct evidence?
