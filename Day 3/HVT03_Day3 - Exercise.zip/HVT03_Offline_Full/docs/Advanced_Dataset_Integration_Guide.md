# Advanced Dataset Integration Guide

This add-on pack is designed to sit alongside the existing HVT03 lab without breaking the current scripts.

## Recommended use order
1. Start with the existing HVT03 core pack and base exports already present in `HVT03_Offline_Full/data/`.
2. Introduce the add-on `http_api/` folder once students understand the original browser/network trace.
3. Add `auth/` and `logs/` together for session, token, and server-side correlation.
4. Add `comms/` and `identity/` once students are ready for deleted-message and attribution pivots.
5. Use `timeline/` and `deceptions/` as late-phase complexity injectors.
6. Reserve `Instructor_Pack/answer_key/` for debrief or marking.

## Strong training chains
- HAR -> cookies -> JWT -> auth audit -> device fingerprints
- Deleted Discord message -> phone map -> identity cluster
- GraphQL schema -> payout requests -> wallets -> payments
- Tracking IDs -> mirror domain -> origin IP -> timeline contradiction review

## Suggested student tasks
- Identify the strongest primary operator hypothesis.
- Separate corroborated leads from seeded decoys.
- Produce a normalized UTC timeline.
- Write a short confidence-rated intelligence note.

All artefacts are synthetic and offline-safe.
