# HVT03 Lab Setup Instructions — Auto-Integrated Edition

## Offline full
Use this when each student runs the target locally.

### Windows
```bat
py lab_manager.py start
py lab_manager.py show
py scriptsscode_runner.py --step all
py lab_manager.py stop
```

### Linux
```bash
python3 lab_manager.py start
python3 lab_manager.py show
python3 scripts/vscode_runner.py --step all
python3 lab_manager.py stop
```

## What `--step all` now does automatically
- headless render and portal recovery
- Discord token recovery from simulated network traces
- Telegram archive export
- Discord archive export
- automatic staging of advanced HTTP/API, auth, log, comms, identity, finance, media, and timeline artefacts
- IOC parsing across both the base and advanced evidence sets
- evidence manifest generation across the expanded corpus

## Simulated credentials
- Burner number: `+447700900123`
- SMS code: `24680`

## Key outputs
- `forensic_vault/rendered_target.html`
- `forensic_vault/advanced_auto/*`
- `Recovered_Discord_Token.txt`
- `TG_Archive_*.csv`
- `TG_Edits_*.json`
- `Discord_Archive_*.csv`
- `Discord_Deleted_*.json`
- `Discord_Mod_Actions_*.json`
- `Discord_Invite_History_*.csv`
- `Extracted_IOC_Report.txt`
- `Extracted_IOC_Report.json`
- `IOC_Target_Matrix.csv`
- `evidence_manifest.txt`
