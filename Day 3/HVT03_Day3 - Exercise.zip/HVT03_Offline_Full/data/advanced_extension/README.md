# Advanced Datasets Expansion

This additive pack extends the HVT03 lab with multi-source correlation artefacts.

## Student Pack
- http_api: HAR, GraphQL, REST, WebSocket evidence
- auth: JWTs, sessions, refresh events, device fingerprints
- logs: server-side access, auth, app errors, proxy headers
- comms: edited/deleted Telegram/Discord and moderation actions
- identity: username, email, phone, and wallet pivot datasets
- media: screenshots, EXIF-bearing images, PDFs, voice note
- finance: payments, wallets, affiliate IDs, payout requests
- timeline: time-normalisation and seeded chronology data
- deceptions: false leads, decoy keys, forged metadata cues

## Instructor Pack
- ground truth
- contradictions matrix
- scoring key
- confidence workbook template
- deception notes

All artefacts are simulated for offline training use.
