import json
import re
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROFILE_PATH = ROOT / "data" / "lab_profile.json"

def load_profile():
    return json.loads(PROFILE_PATH.read_text(encoding="utf-8"))

def fetch_text(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
    with urllib.request.urlopen(req, timeout=20) as resp:
        return resp.read().decode("utf-8", errors="replace")

def fetch_json(url):
    return json.loads(fetch_text(url))

def extract_boot_from_bundle(js_text):
    render = re.search(r'render:\s*"([^"]+)"', js_text)
    trace = re.search(r'trace:\s*"([^"]+)"', js_text)
    assets = re.search(r'assets:\s*"([^"]+)"', js_text)
    if not render:
        raise RuntimeError("render endpoint not found in app bundle")
    return {
        "render": render.group(1),
        "trace": trace.group(1) if trace else None,
        "assets": assets.group(1) if assets else None,
    }

def headless_breach():
    profile = load_profile()
    base = profile.get("base_url", "http://127.0.0.1:8030").rstrip("/")
    target_url = f"{base}/portal"
    print("--- INITIATING HEADLESS INFILTRATOR (LAB SIMULATION) ---")
    print(f"[*] Target: {target_url}")

    vault = ROOT / "forensic_vault"
    vault.mkdir(exist_ok=True)

    raw_html = fetch_text(target_url)
    (vault / "raw_portal.html").write_text(raw_html, encoding="utf-8")

    script_match = re.search(r'<script src="([^"]+)"></script>\s*</body>', raw_html)
    if not script_match:
        raise SystemExit("[-] Unable to locate app bundle in raw portal.")
    app_src = script_match.group(1)

    app_bundle = fetch_text(base + app_src)
    (vault / "app_bundle.js").write_text(app_bundle, encoding="utf-8")
    boot = extract_boot_from_bundle(app_bundle)

    render_json = fetch_json(base + boot["render"])
    (vault / "render_payload.json").write_text(json.dumps(render_json, indent=2), encoding="utf-8")

    if boot.get("trace"):
        trace_json = fetch_json(base + boot["trace"])
        (vault / "network_trace.json").write_text(json.dumps(trace_json, indent=2), encoding="utf-8")

    if boot.get("assets"):
        asset_json = fetch_json(base + boot["assets"])
        (vault / "asset_manifest.json").write_text(json.dumps(asset_json, indent=2), encoding="utf-8")
    else:
        asset_json = {"visible_tags": []}

    rendered_html = f"""<!doctype html>
<html><head><meta charset="utf-8"><title>{render_json['portal_name']}</title></head>
<body>
<h1>{render_json['portal_name']}</h1>
<p>{render_json['tagline']}</p>
<div id="tracking">Tracking ID: {render_json['tracking_id']}</div>
<div id="gtm">Tag Manager: {render_json['tag_manager_id']}</div>
<div id="telegram">Telegram: {render_json['telegram_handle']}</div>
<div id="discord">Discord Channel ID: {render_json['discord_channel_id']}</div>
<div id="hint">Portal hint: {render_json['portal_admin_hint']}</div>
<div id="tags">{' | '.join(asset_json.get('visible_tags', []))}</div>
<ul>
{''.join([f"<li><a href='{item['href']}'>{item['label']}</a></li>" for item in render_json['links']])}
</ul>
</body></html>"""
    out_file = vault / "rendered_target.html"
    out_file.write_text(rendered_html, encoding="utf-8")

    summary = [
        f"Render scene: {profile['render_scene']}",
        f"Tracking ID: {render_json['tracking_id']}",
        f"Tag Manager: {render_json['tag_manager_id']}",
        f"Telegram handle: {render_json['telegram_handle']}",
        f"Discord channel ID: {render_json['discord_channel_id']}",
        f"Admin hint: {render_json['portal_admin_hint']}",
    ]
    (vault / "headless_summary.txt").write_text("\n".join(summary) + "\n", encoding="utf-8")

    print(f"[✓] Raw portal secured at: {vault / 'raw_portal.html'}")
    print(f"[✓] App bundle secured at: {vault / 'app_bundle.js'}")
    print(f"[✓] Rendered payload secured at: {out_file}")
    print(f"[*] Extracted tracking ID: {render_json['tracking_id']}")
    print(f"[*] Extracted Tag Manager: {render_json['tag_manager_id']}")
    print(f"[*] Extracted Telegram handle: {render_json['telegram_handle']}")
    print(f"[*] Extracted Discord channel ID: {render_json['discord_channel_id']}")
    return 0

if __name__ == "__main__":
    raise SystemExit(headless_breach())
