import json
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, quote
from pathlib import Path
import argparse

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"

PROFILE = json.loads((DATA_DIR / "lab_profile.json").read_text(encoding="utf-8"))
DISCORD_MESSAGES = json.loads((DATA_DIR / "mock_discord_messages.json").read_text(encoding="utf-8"))
TELEGRAM_MESSAGES = json.loads((DATA_DIR / "mock_telegram_messages.json").read_text(encoding="utf-8"))
NETWORK_TRACE = json.loads((DATA_DIR / "mock_browser_network_trace.json").read_text(encoding="utf-8"))
ASSET_MANIFEST = json.loads((DATA_DIR / "asset_manifest.json").read_text(encoding="utf-8"))

def newest_first(items):
    return list(reversed(items))

class Handler(BaseHTTPRequestHandler):
    server_version = "AsterionEdge/3.7"

    def log_message(self, format, *args):
        return

    def _send_json(self, payload, status=200):
        body = json.dumps(payload, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Server", "cloudflare")
        self.send_header("CF-RAY", "simulated-js-challenge-v3")
        self.end_headers()
        self.wfile.write(body)

    def _send_text(self, text, status=200, content_type="text/plain; charset=utf-8"):
        body = text.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Server", "cloudflare")
        self.send_header("CF-RAY", "simulated-js-challenge-v3")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        qs = parse_qs(parsed.query)

        if path in ("/", "/portal", "/reactor"):
            html = f"""<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>{PROFILE['page_title']}</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {{font-family: Arial, sans-serif; margin:0; background:#0f172a; color:#e5e7eb;}}
header {{padding:28px 36px; background:linear-gradient(90deg,#111827,#1f2937); border-bottom:1px solid #334155;}}
main {{padding:32px 36px; max-width:1180px; margin:0 auto;}}
.card {{background:#111827; border:1px solid #334155; border-radius:14px; padding:20px; margin-bottom:18px; box-shadow:0 10px 24px rgba(0,0,0,.25);}}
.small {{color:#94a3b8; font-size:0.92rem;}}
.grid {{display:grid; grid-template-columns:repeat(auto-fit,minmax(240px,1fr)); gap:14px;}}
code {{background:#0b1220; padding:2px 6px; border-radius:6px;}}
</style>
</head>
<body>
<header>
  <h1>{PROFILE['page_title']}</h1>
  <div class="small">Dynamic investor-facing portal. JavaScript required. Static source alone is incomplete.</div>
</header>
<main>
  <div class="card">
    <h2>Challenge Gateway</h2>
    <p class="small">This page intentionally withholds the useful content until the app bundle boots and fetches the render API.</p>
    <div id="app">Loading secure workspace…</div>
  </div>
  <div class="card">
    <h3>Common student traps</h3>
    <ul class="small">
      <li>Decoy Telegram handle in raw markup: <code>@decoy_ops_feed</code></li>
      <li>Decoy note: "open the public bulletin first"</li>
      <li>Useful values appear only after the app bundle executes</li>
    </ul>
  </div>
</main>
<script>
window.__LAB_DECOY_HANDLE__ = "@decoy_ops_feed";
window.__LAB_DECOY_NOTE__ = "follow the public board only";
</script>
<script src="/static/app.bundle.js"></script>
</body></html>"""
            self._send_text(html, content_type="text/html; charset=utf-8")
            return

        if path == "/static/app.bundle.js":
            js = f"""(function(){{
const BOOT = {{
  render: "/api/render?scene={PROFILE['render_scene']}",
  trace: "/api/mock-devtools/network-trace",
  assets: "/api/assets/manifest"
}};
window.__APP_BOOT__ = BOOT;
async function boot(){{
  const [renderRes, assetRes] = await Promise.all([fetch(BOOT.render), fetch(BOOT.assets)]);
  const data = await renderRes.json();
  const assets = await assetRes.json();
  const app = document.getElementById("app");
  app.innerHTML = `
    <div class="grid">
      <div class="card"><h3>${{data.portal_name}}</h3><p>${{data.tagline}}</p><div class="small">Tracking ID: ${{data.tracking_id}}</div><div class="small">Tag Manager: ${{data.tag_manager_id}}</div></div>
      <div class="card"><h3>Research Drop</h3><ul>${{data.links.map(x => `<li><a href="${{x.href}}" style="color:#93c5fd">${{x.label}}</a></li>`).join('')}}</ul></div>
      <div class="card"><h3>Operations Notes</h3><p>Telegram: <code>${{data.telegram_handle}}</code></p><p>Discord channel: <code>${{data.discord_channel_id}}</code></p><p class="small">${{data.portal_admin_hint}}</p></div>
      <div class="card"><h3>Visible Tags</h3><p>${{assets.visible_tags.join(' | ')}}</p><p class="small">Campaign: ${{assets.campaign}}</p></div>
    </div>`;
}}
boot();
}})();"""
            self._send_text(js, content_type="application/javascript; charset=utf-8")
            return

        if path == "/api/render":
            scene = qs.get("scene", [""])[0]
            if scene != PROFILE["render_scene"]:
                self._send_json({"error": "unknown scene"}, 404)
                return
            self._send_json({
                "portal_name": PROFILE["page_title"],
                "tagline": "Private communications workspace for vetted operators only.",
                "tracking_id": PROFILE["tracking_id"],
                "tag_manager_id": PROFILE["tag_manager_id"],
                "telegram_handle": PROFILE["telegram_handle"],
                "discord_channel_id": PROFILE["discord_channel_id"],
                "portal_admin_hint": PROFILE["portal_admin_hint"],
                "links": ASSET_MANIFEST["documents"]
            })
            return

        if path == "/api/assets/manifest":
            self._send_json(ASSET_MANIFEST)
            return

        if path == "/api/mock-devtools/network-trace":
            self._send_json(NETWORK_TRACE)
            return

        if path.startswith("/api/mock-telegram/channel/"):
            handle = path.split("/")[-1]
            if not handle.startswith("@"):
                handle = "@" + handle
            if handle != PROFILE["telegram_handle"]:
                self._send_json({"error": "channel not found"}, 404)
                return
            limit = min(int(qs.get("limit", ["50"])[0]), 100)
            offset = max(int(qs.get("offset", ["0"])[0]), 0)
            rows = newest_first(TELEGRAM_MESSAGES)
            sliced = rows[offset:offset+limit]
            self._send_json({
                "channel": handle,
                "limit": limit,
                "offset": offset,
                "has_more": offset + limit < len(rows),
                "messages": sliced
            })
            return

        if path.startswith("/api/mock-discord/channels/") and path.endswith("/messages"):
            parts = path.split("/")
            channel_id = parts[-2]
            auth = self.headers.get("Authorization", "")
            if auth != PROFILE["discord_token"]:
                self._send_json({"error": "Unauthorized"}, 401)
                return
            if channel_id != PROFILE["discord_channel_id"]:
                self._send_json({"error": "Unknown channel"}, 404)
                return
            limit = min(int(qs.get("limit", ["100"])[0]), 100)
            before = qs.get("before", [None])[0]
            messages = newest_first(DISCORD_MESSAGES)
            if before:
                try:
                    idx = next(i for i, m in enumerate(messages) if m["id"] == before)
                    messages = messages[idx+1:]
                except StopIteration:
                    messages = []
            self._send_json(messages[:limit])
            return

        if path == "/briefs/field-research.html":
            self._send_text(
                f"<html><body><h1>Field Research Brief</h1><p>Pivot ID: {PROFILE['tracking_id']}</p><p>Tag Manager: {PROFILE['tag_manager_id']}</p><p>Primary telegram handle: {PROFILE['telegram_handle']}</p></body></html>",
                content_type="text/html; charset=utf-8"
            )
            return

        if path == "/ir/mirror.html":
            self._send_text(
                "<html><body><h1>Investor Relations Mirror</h1><p>Decoy mirror. No chat data here.</p></body></html>",
                content_type="text/html; charset=utf-8"
            )
            return

        if path == "/archive/cases.html":
            self._send_text(
                "<html><body><h1>Case Archive</h1><p>Narrative-only material. Students should recognise this as background context, not a live feed.</p></body></html>",
                content_type="text/html; charset=utf-8"
            )
            return

        if path == "/notes/ops-notebook.txt":
            self._send_text(
                f"admin alias {PROFILE['primary_alias']}\nbackup email {PROFILE['backup_email']}\nedge {PROFILE['tracking_id']} / {PROFILE['tag_manager_id']}\n",
                content_type="text/plain; charset=utf-8"
            )
            return

        self._send_json({"error": "Not found"}, 404)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8030)
    args = parser.parse_args()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    print(f"[*] HVT03 target server listening on http://127.0.0.1:{args.port}")
    server.serve_forever()

if __name__ == "__main__":
    main()
