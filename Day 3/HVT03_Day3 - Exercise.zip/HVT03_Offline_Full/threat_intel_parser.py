import csv
import json
import re
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ADV_ROOT = ROOT / 'data' / 'advanced_extension'

PATTERNS = {
    'Tracking_IDs': re.compile(r'\b(?:UA-\d{4,10}-\d{1,4}|GTM-[A-Z0-9]{5,10}|G-[A-Z0-9-]{5,15})\b'),
    'BTC_Wallets': re.compile(r'\b(?:bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}\b'),
    'ETH_Wallets': re.compile(r'\b0x[a-fA-F0-9]{40}\b'),
    'Monero_Wallets': re.compile(r'\b4[0-9AB][1-9A-HJ-NP-Za-km-z]{93}\b'),
    'IPv4_Nodes': re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}(?::\d{2,5})?\b'),
    'Tor_Onion_Links': re.compile(r'\b[a-z2-7]{16,56}\.onion\b'),
    'Mega_Links': re.compile(r'https?://mega\.nz/(?:file|folder)/[a-zA-Z0-9#_-]+'),
    'Emails': re.compile(r'\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,}\b'),
    'Telegram_Handles': re.compile(r'(?<!\w)@[A-Za-z0-9_]{4,}\b'),
    'Discord_Invite_Codes': re.compile(r'\b[A-Z0-9-]{6,20}\b'),
    'Domains': re.compile(r'\b(?:[a-z0-9-]+\.)+[a-z]{2,}\b'),
}

EXCLUDE_DOMAINS = {'mega.nz'}
TEXT_EXTS = {'.html', '.txt', '.js', '.json', '.jsonl', '.csv', '.log', '.har', '.md'}


def read_textish(path: Path) -> str:
    try:
        return path.read_text(encoding='utf-8', errors='replace')
    except Exception:
        return ''


def candidate_files():
    files = set()
    for base in [ROOT / 'forensic_vault', ADV_ROOT]:
        if base.exists():
            for p in base.rglob('*'):
                if p.is_file() and p.suffix.lower() in TEXT_EXTS:
                    files.add(p)
    for pat in [
        'TG_Archive_*.csv',
        'TG_Archive_*.json',
        'TG_Edits_*.json',
        'Discord_Archive_*.csv',
        'Discord_Archive_*.json',
        'Discord_Deleted_*.json',
        'Discord_Mod_Actions_*.json',
        'Discord_Invite_History_*.csv',
        'Recovered_*.txt',
        'UCO_Session.session',
    ]:
        files.update(ROOT.glob(pat))
    return sorted(files)


def parse():
    files = candidate_files()
    if not files:
        print('[-] No candidate files found for parsing.')
        return 1

    seen = defaultdict(lambda: defaultdict(set))
    for path in files:
        content = read_textish(path)
        for category, pattern in PATTERNS.items():
            for match in pattern.findall(content):
                ioc = match.strip()
                if category == 'Domains' and ioc.lower() in EXCLUDE_DOMAINS:
                    continue
                seen[category][ioc].add(path.name)

    report_txt = ROOT / 'Extracted_IOC_Report.txt'
    report_json = ROOT / 'Extracted_IOC_Report.json'
    matrix_csv = ROOT / 'IOC_Target_Matrix.csv'

    total_hits = sum(len(v) for v in seen.values())
    with report_txt.open('w', encoding='utf-8') as out:
        out.write('AUTOMATED THREAT INTELLIGENCE REPORT\n')
        out.write(f'Files scanned: {len(files)}\n')
        out.write(f'Unique IOC values: {total_hits}\n')
        out.write('Advanced dataset mode: ENABLED (automatic)\n\n')
        for category in sorted(seen):
            out.write(f'--- {category} FOUND: {len(seen[category])} ---\n')
            for ioc in sorted(seen[category]):
                out.write(f"{ioc} | sources={', '.join(sorted(seen[category][ioc]))}\n")
            out.write('\n')

    json_payload = {
        'advanced_dataset_auto_enabled': True,
        'files_scanned': [str(p.relative_to(ROOT)) for p in files],
        'categories': {
            category: [
                {'ioc': ioc, 'sources': sorted(list(srcs))}
                for ioc, srcs in sorted(values.items())
            ]
            for category, values in sorted(seen.items())
        },
    }
    report_json.write_text(json.dumps(json_payload, indent=2), encoding='utf-8')

    with matrix_csv.open('w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Category', 'IOC', 'Sources', 'Source_Count'])
        for category in sorted(seen):
            for ioc, sources in sorted(seen[category].items()):
                writer.writerow([category, ioc, ' | '.join(sorted(sources)), len(sources)])

    print(f'[✓] Scan complete. Processed {len(files)} files.')
    print(f'[*] Text report: {report_txt.name}')
    print(f'[*] JSON report: {report_json.name}')
    print(f'[*] IOC matrix: {matrix_csv.name}')
    return 0


if __name__ == '__main__':
    raise SystemExit(parse())
