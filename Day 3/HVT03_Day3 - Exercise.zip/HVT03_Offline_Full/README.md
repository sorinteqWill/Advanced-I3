# HVT03 Expanded Dual Bundle — Start Command Auto-Run Edition

This edition keeps the same familiar entry point as before.

## Default command
```bash
python3 lab_manager.py start
```

That single command now does all of the following automatically:
- starts the local target lab
- starts the scoreboard server
- clears prior run artefacts
- runs the full Day 3 default evidence pipeline
- stages and uses the advanced dataset automatically
- generates the IOC report and evidence manifest

## Optional commands
- `python3 lab_manager.py start-services` — start only the local services without auto-running the pipeline
- `python3 lab_manager.py show` — print URLs and artefact locations
- `python3 lab_manager.py stop` — stop the local lab services

## Primary outputs
- `forensic_vault/`
- `Extracted_IOC_Report.json`
- `Extracted_IOC_Report.txt`
- `IOC_Target_Matrix.csv`
- `evidence_manifest.txt`
