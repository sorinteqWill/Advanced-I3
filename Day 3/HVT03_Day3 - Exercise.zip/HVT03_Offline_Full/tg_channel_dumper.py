import csv
import json
import os
import shutil
import sys
from pathlib import Path
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parent
PROFILE_PATH = ROOT / 'data' / 'lab_profile.json'
SESSION_PATH = ROOT / 'UCO_Session.session'
ADV_ROOT = ROOT / 'data' / 'advanced_extension'


def load_profile():
    return json.loads(PROFILE_PATH.read_text(encoding='utf-8'))


def ensure_session(profile):
    if SESSION_PATH.exists():
        print(f"[*] Reusing existing session file: {SESSION_PATH.name}")
        return
    print('[*] First-run authentication required for lab UCO account.')
    print(f"[*] Simulated burner number: {profile['telegram_phone']}")
    env_code = os.environ.get('TELEGRAM_SMS_CODE', '').strip()
    if env_code:
        code = env_code
        print('[*] Using TELEGRAM_SMS_CODE from environment.')
    elif not sys.stdin.isatty():
        code = str(profile['telegram_sms_code']).strip()
        print('[*] Non-interactive run detected; using the instructor-pack lab SMS code.')
    else:
        code = input('Enter the 5-digit SMS code shown by the instructor pack: ').strip()
    if code != profile['telegram_sms_code']:
        raise SystemExit('[-] Incorrect lab SMS code.')
    SESSION_PATH.write_text(json.dumps({'phone': profile['telegram_phone'], 'authorised': True}, indent=2), encoding='utf-8')
    print(f"[✓] Session file created: {SESSION_PATH.name}")


def dump_telegram_channel():
    profile = load_profile()
    ensure_session(profile)
    base_url = profile['base_url'].rstrip('/')
    handle = profile['telegram_handle']

    offset = 0
    page_size = 50
    all_messages = []
    while True:
        url = f"{base_url}/api/mock-telegram/channel/{urllib.parse.quote(handle.lstrip('@'))}?limit={page_size}&offset={offset}"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=15) as resp:
            payload = json.loads(resp.read().decode('utf-8'))
        batch = payload['messages']
        all_messages.extend(batch)
        if not payload.get('has_more'):
            break
        offset += page_size

    csv_file = ROOT / f"TG_Archive_{handle.replace('@', '')}.csv"
    with csv_file.open('w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Message_ID', 'Timestamp_UTC', 'Sender_ID', 'Message_Text'])
        for msg in all_messages:
            writer.writerow([msg['id'], msg['date'], msg['sender_id'], msg['text'].replace('\n', ' ')])

    json_file = ROOT / f"TG_Archive_{handle.replace('@', '')}.json"
    json_file.write_text(json.dumps({'channel': handle, 'messages': all_messages}, indent=2), encoding='utf-8')

    edits_src = ADV_ROOT / 'comms' / 'telegram_edits.json'
    if edits_src.exists():
        edits_dst = ROOT / f"TG_Edits_{handle.replace('@', '')}.json"
        shutil.copy2(edits_src, edits_dst)
        print(f"[*] Advanced Telegram edit-history staged: {edits_dst.name}")

    print(f"[✓] Telegram extraction complete. {len(all_messages)} records secured.")
    print(f"[*] CSV: {csv_file.name}")
    print(f"[*] JSON: {json_file.name}")
    return 0


if __name__ == '__main__':
    raise SystemExit(dump_telegram_channel())
