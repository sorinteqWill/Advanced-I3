import hashlib
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ADV_ROOT = ROOT / 'data' / 'advanced_extension'


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()


def seal():
    targets = set()
    for base in [ROOT / 'forensic_vault', ADV_ROOT]:
        if base.exists():
            for item in base.rglob('*'):
                if item.is_file():
                    targets.add(item)
    for pat in [
        'TG_Archive_*.csv',
        'TG_Archive_*.json',
        'TG_Edits_*.json',
        'Discord_Archive_*.csv',
        'Discord_Archive_*.json',
        'Discord_Deleted_*.json',
        'Discord_Mod_Actions_*.json',
        'Discord_Invite_History_*.csv',
        'Extracted_IOC_Report.*',
        'IOC_Target_Matrix.csv',
        'Recovered_*.txt',
        'UCO_Session.session',
    ]:
        targets.update(ROOT.glob(pat))

    manifest = ROOT / 'evidence_manifest.txt'
    with manifest.open('w', encoding='utf-8') as out:
        out.write(f"Evidence Manifest generated UTC {datetime.now(timezone.utc).isoformat()}Z\n")
        out.write('Advanced dataset mode: ENABLED (automatic)\n\n')
        for item in sorted(targets):
            if item.is_file():
                rel = item.relative_to(ROOT)
                out.write(f'{rel}: {sha256_file(item)}\n')

    print(f'[✓] Evidence sealed to {manifest.name}')
    return 0


if __name__ == '__main__':
    raise SystemExit(seal())
