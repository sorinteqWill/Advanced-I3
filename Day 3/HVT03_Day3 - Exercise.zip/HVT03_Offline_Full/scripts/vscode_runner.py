import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STEPS = [
    "headless_infiltrator.py",
    "network_trace_recover.py",
    "tg_channel_dumper.py",
    "discord_infiltrator.py",
    "threat_intel_parser.py",
    "evidence_sealer.py",
]

def run_step(name):
    return subprocess.call([sys.executable, str(ROOT / name)], cwd=ROOT)

def main():
    step = "all"
    if "--step" in sys.argv:
        idx = sys.argv.index("--step")
        if idx + 1 < len(sys.argv):
            step = sys.argv[idx + 1]
    if step == "all":
        code = 0
        for item in STEPS:
            rc = run_step(item)
            code = code or rc
        return code
    mapping = {
        "headless": "headless_infiltrator.py",
        "trace": "network_trace_recover.py",
        "telegram": "tg_channel_dumper.py",
        "discord": "discord_infiltrator.py",
        "parser": "threat_intel_parser.py",
        "seal": "evidence_sealer.py",
    }
    target = mapping.get(step, step)
    return run_step(target)

if __name__ == "__main__":
    raise SystemExit(main())
