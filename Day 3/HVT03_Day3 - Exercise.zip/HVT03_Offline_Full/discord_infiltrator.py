import csv
import json
import shutil
import time
from pathlib import Path
import urllib.error
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parent
PROFILE_PATH = ROOT / 'data' / 'lab_profile.json'
TOKEN_FILE = ROOT / 'Recovered_Discord_Token.txt'
ADV_ROOT = ROOT / 'data' / 'advanced_extension'


def load_profile():
    return json.loads(PROFILE_PATH.read_text(encoding='utf-8'))


def load_token(profile):
    if TOKEN_FILE.exists():
        token = TOKEN_FILE.read_text(encoding='utf-8').strip()
        if token:
            print(f"[*] Using recovered token from {TOKEN_FILE.name}")
            return token
    return profile['discord_token']


def archive_discord_channel():
    profile = load_profile()
    base_url = profile['base_url'].rstrip('/')
    channel_id = profile['discord_channel_id']
    token = load_token(profile)
    output_csv = ROOT / f'Discord_Archive_{channel_id}.csv'
    output_json = ROOT / f'Discord_Archive_{channel_id}.json'
    total = 0
    last_message_id = None
    all_messages = []

    with output_csv.open('w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Message_ID', 'Timestamp', 'Author', 'Content', 'Attachments'])
        while True:
            url = f'{base_url}/api/mock-discord/channels/{channel_id}/messages?limit=100'
            if last_message_id:
                url += f'&before={urllib.parse.quote(last_message_id)}'
            req = urllib.request.Request(
                url,
                headers={
                    'Authorization': token,
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
                },
            )
            try:
                with urllib.request.urlopen(req, timeout=15) as resp:
                    messages = json.loads(resp.read().decode('utf-8'))
            except urllib.error.HTTPError as e:
                if e.code == 401:
                    print('[-] Critical Error: UCO Token is invalid or expired.')
                    return 1
                raise
            if not messages:
                break
            for msg in messages:
                attachments = ' | '.join(att['url'] for att in msg.get('attachments', [])) if msg.get('attachments') else 'None'
                writer.writerow([
                    msg['id'],
                    msg['timestamp'],
                    msg['author']['username'],
                    msg.get('content', '').replace('\n', ' '),
                    attachments,
                ])
                last_message_id = msg['id']
                total += 1
                all_messages.append(msg)
            time.sleep(0.02)

    output_json.write_text(json.dumps(all_messages, indent=2), encoding='utf-8')

    extras = [
        (ADV_ROOT / 'comms' / 'discord_deleted_messages.json', ROOT / f'Discord_Deleted_{channel_id}.json'),
        (ADV_ROOT / 'comms' / 'mod_actions.json', ROOT / f'Discord_Mod_Actions_{channel_id}.json'),
        (ADV_ROOT / 'comms' / 'invite_history.csv', ROOT / f'Discord_Invite_History_{channel_id}.csv'),
    ]
    for src, dst in extras:
        if src.exists():
            shutil.copy2(src, dst)
            print(f"[*] Advanced Discord artefact staged: {dst.name}")

    print(f'[✓] Discord infiltration complete. {total} messages secured.')
    print(f'[*] CSV: {output_csv.name}')
    print(f'[*] JSON: {output_json.name}')
    return 0


if __name__ == '__main__':
    raise SystemExit(archive_discord_channel())
