# Deception Notes

## Intended student traps
- `ops_admin_backup` appears privileged but is weakly supported and fails escalation.
- The `bc1qdec0y...` wallet appears in finance material but only in cancelled/seeded items.
- `+447700900124` is a decoy phone.
- EXIF local timestamps without explicit offsets should be treated carefully.
- `vendor_invoice.pdf` metadata is intentionally offset to create a timeline contradiction.

## Strongest converging artefacts
- JWT payloads
- websocket payout event
- deleted Discord phone-leak message
- historical analytics IDs
- mirror domain + origin IP references
