import argparse, json, subprocess, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
def run(cmd):
    print(f"\n$ {' '.join(cmd)}")
    return subprocess.call(cmd, cwd=ROOT)
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--step", default="all"); args=ap.parse_args()
    cfg={}
    env=ROOT/".lab_env.json"
    if env.exists(): cfg=json.loads(env.read_text(encoding="utf-8"))
    base=cfg.get("base_url","http://127.0.0.1:8000"); host=cfg.get("host_header","ransom-leak-portal.io")
    steps={
        "seal":[sys.executable,"proxy_seal_check.py"],
        "ct":[sys.executable,"ct_searcher.py","--feed",f"{base}/lab/ctfeed.json"],
        "waf":[sys.executable,"waf_detector.py","--url",base+"/"],
        "hash":[sys.executable,"icon_hasher.py","--url",base+"/favicon.ico"],
        "fuzz":[sys.executable,"api_leak_fuzzer.py","--base",base,"--host-header",host],
        "bola":[sys.executable,"bola_tester.py","--base",base+"/api/v1/victims/","--host-header",host],
        "slice":[sys.executable,"log_slicer.py"],
        "seal_evidence":[sys.executable,"evidence_sealer.py"],
    }
    order=["seal","ct","waf","hash","fuzz","bola","slice","seal_evidence"]
    if args.step == "all":
        rc=0
        for s in order: rc = run(steps[s]) or rc
        raise SystemExit(rc)
    raise SystemExit(run(steps[args.step]))
if __name__ == "__main__": main()
