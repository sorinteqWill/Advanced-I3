import argparse, time, urllib.request, urllib.error
from pathlib import Path
def read_wordlist(path): return [ln.strip() for ln in Path(path).read_text(encoding="utf-8").splitlines() if ln.strip()]
def check(base, path, host):
    url = base.rstrip("/") + "/" + path.lstrip("/")
    req = urllib.request.Request(url, headers={"User-Agent":"Mozilla/5.0","Host":host})
    try:
        with urllib.request.urlopen(req, timeout=8) as r: return r.status, url
    except urllib.error.HTTPError as e: return e.code, url
    except Exception: return None, url
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--base", default="http://127.0.0.1:8000"); ap.add_argument("--host-header", default="ransom-leak-portal.io"); ap.add_argument("--wordlist", default="data/api_paths.txt"); ap.add_argument("--sleep", type=float, default=0.25); args=ap.parse_args()
    print("--- API LEAK FUZZER ---")
    for p in read_wordlist(args.wordlist):
        status, url = check(args.base, p, args.host_header)
        if status in (200,403):
            label = "[!] CRITICAL EXPOSURE FOUND" if status == 200 and "api/v1/victims/" in p else "[*] Interesting"
            print(f"{label} {status} -> /{p}")
        time.sleep(args.sleep)
if __name__ == "__main__": main()
