import hashlib, json, platform, time
from pathlib import Path
ROOT = Path(__file__).resolve().parent
profile = ROOT / "data" / "lab_proxy_profile.json"
blob = profile.read_bytes()
seal = hashlib.sha256(blob).hexdigest()
print("--- OPERATIONAL PROXY SEAL CHECK ---")
print(f"[✓] Profile loaded: {profile.name}")
print(f"[✓] Seal (SHA-256): {seal}")
print(f"[*] Host: {platform.node()}  Time: {time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime())}")
print("[*] Lab mode is classroom-contained. No external network routing is required.")
