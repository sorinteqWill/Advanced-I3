import argparse, json, urllib.request
from pathlib import Path
def load_feed(target):
    if target.startswith("http://") or target.startswith("https://"):
        with urllib.request.urlopen(target, timeout=10) as r:
            return json.loads(r.read().decode("utf-8"))
    return json.loads(Path(target).read_text(encoding="utf-8"))
def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--feed", default="http://ransom-leak-portal.io/lab/ctfeed.json"); args = ap.parse_args()
    print("--- CT SEARCHER (LAB MIRROR) ---")
    entries = load_feed(args.feed)
    for e in entries:
        tag = "[!] EXPOSED ORIGIN" if not e.get("proxied", True) else "[*] proxied"
        print(f"{tag} {e['name_value']:<30} {e['ip']:<15} {e['asn']}")
    origins = [e for e in entries if not e.get("proxied", True)]
    if origins: print(f"\n[✓] Primary exposed origin candidate: {origins[0]['ip']}")
if __name__ == "__main__": main()
