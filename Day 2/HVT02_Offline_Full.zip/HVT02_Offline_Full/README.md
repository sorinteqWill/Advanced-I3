# HVT-02 Offline Full

Run `py lab_manager.py start`, then `py scripts\\vscode_runner.py --step all`, then `py lab_manager.py stop`.
