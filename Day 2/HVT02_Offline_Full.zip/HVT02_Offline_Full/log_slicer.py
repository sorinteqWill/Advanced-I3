import argparse, mmap, re
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--file", default="logs/apache_seized.log"); ap.add_argument("--needle", default="Admin_Phantom"); args=ap.parse_args()
    print("--- LOG SLICER ---")
    with open(args.file, "rb") as f:
        mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
        idx = mm.find(args.needle.encode("utf-8"))
        if idx == -1: print("[-] Needle not found"); return
        start = mm.rfind(b"\n", 0, idx) + 1; end = mm.find(b"\n", idx); end = len(mm) if end == -1 else end
        line = mm[start:end].decode("utf-8", errors="replace"); print(f"[✓] Matching line: {line}")
        m = re.search(r'(\d+\.\d+\.\d+\.\d+).*\[([^\]]+)\].*user=([A-Za-z0-9_]+)', line)
        if m:
            print(f"[✓] Admin IP: {m.group(1)}"); print(f"[✓] Login timestamp UTC: {m.group(2)}"); print(f"[✓] Username: {m.group(3)}")
        mm.close()
if __name__ == "__main__": main()
