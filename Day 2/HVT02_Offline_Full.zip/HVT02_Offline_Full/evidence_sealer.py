import argparse, hashlib, time
from pathlib import Path
def sha256_of(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(65536), b""): h.update(chunk)
    return h.hexdigest()
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--paths", nargs="*", default=["bola_exfil_log.csv","logs/apache_seized.log"]); ap.add_argument("--out", default="evidence_manifest.txt"); args=ap.parse_args()
    print("--- EVIDENCE SEALER ---"); lines=[f"Evidence manifest generated UTC: {time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime())}"]
    for p in args.paths:
        path=Path(p)
        if path.exists():
            d=sha256_of(path); line=f"{path}\tSHA256\t{d}"; lines.append(line); print(f"[✓] {line}")
    Path(args.out).write_text("\n".join(lines), encoding="utf-8"); print(f"[✓] Manifest written to {args.out}")
if __name__ == "__main__": main()
