
# HVT-02 Instructor Walkthrough

## Core objective chain
1. Run `proxy_seal_check.py`
2. Run `ct_searcher.py` and note the exposed origin IP
3. Run `waf_detector.py` and confirm Cloudflare-style headers
4. Run `icon_hasher.py` and record the favicon hash dork
5. Run `api_leak_fuzzer.py` against the origin IP
6. Confirm `/api/v1/victims/` is exposed
7. Run `bola_tester.py` for IDs 1-50
8. Run `log_slicer.py` and record:
   - admin username
   - admin IP
   - exact UTC login timestamp
9. Run `evidence_sealer.py`

## Instructor expected answers
- Exposed origin IP: the IP shown by `ct_searcher.py`
- WAF: Cloudflare-style edge shield
- Favicon dork: the exact `http.favicon.hash:<integer>` output
- Open endpoint: `/api/v1/victims/`
- Victim data: at least 50 profiles exported to CSV
- Admin username: `Admin_Phantom`
- Admin IP: `192.168.1.55`
- Admin login timestamp: `17/Mar/2026:23:15:00 +0000`

## Common student errors
- Forgetting to edit the hosts file in the classroom version
- Pointing the fuzzer at the domain instead of the verified origin IP
- Forgetting the host header when working directly against an IP
- Trying to open the seized log in a text editor instead of using the slicer
- Failing to seal the CSV and log with evidence hashes

## Suggested 60-minute pacing
- 0-10 min: setup and seal check
- 10-20 min: origin discovery and WAF confirmation
- 20-35 min: favicon hash and API fuzzing
- 35-45 min: BOLA extraction
- 45-55 min: log slicing and evidence sealing
- 55-60 min: debrief and report writing


## Expanded bundle note
This package preserves the original objective chain while increasing the amount of data and realism for stronger cohorts.
