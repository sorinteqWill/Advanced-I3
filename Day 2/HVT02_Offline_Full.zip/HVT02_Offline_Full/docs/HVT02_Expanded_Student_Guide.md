# HVT-02 Expanded Student Guide

## Mission
Investigate the ransomware leak portal and produce a minimal evidential package that:
- identifies the exposed origin candidate
- confirms the edge shield
- extracts a favicon-based pivot
- discovers the exposed API route
- exports victim data
- attributes the operator from the seized Apache log
- seals the evidence with SHA-256

## Core sequence
1. `python proxy_seal_check.py`
2. `python ct_searcher.py --feed http://ransom-leak-portal.io/lab/ctfeed.json`
3. `python waf_detector.py --url http://ransom-leak-portal.io/`
4. `python icon_hasher.py --url http://ransom-leak-portal.io/favicon.ico`
5. `python api_leak_fuzzer.py --base http://ransom-leak-portal.io --host-header ransom-leak-portal.io`
6. `python bola_tester.py --base http://ransom-leak-portal.io/api/v1/victims/ --host-header ransom-leak-portal.io`
7. `python log_slicer.py`
8. `python evidence_sealer.py`

## Required student deliverables
- terminal capture of the CT origin result
- terminal capture of the WAF result
- terminal capture of the favicon dork
- `bola_exfil_log.csv`
- terminal capture of the admin line recovered from the seized log
- `evidence_manifest.txt`

## Optional advanced tasks
- Count victims by country from the CSV
- Count victims by sector from the CSV
- Determine how many domains in the favicon index share the same icon
- Identify every non-proxied host in the CT feed
- Compare attacker_intel.log activity with the recovered admin login window
