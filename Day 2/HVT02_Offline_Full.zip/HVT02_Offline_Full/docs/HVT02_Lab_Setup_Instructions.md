
# HVT-02 Lab Setup Instructions

## What this package contains
This Day 2 lab is provided in two forms:

1. **Slide-faithful local-hosted classroom version**
   - The instructor starts the target on their machine.
   - Students access it over the classroom LAN.
   - This version mirrors the slide flow most closely.

2. **Offline full version**
   - Everything runs on one machine.
   - Useful for rehearsal, testing, and fully isolated delivery.

## Minimum requirements
- Python 3 installed
- ZIP fully extracted to a writable local folder
- VS Code recommended but not required

## Slide-faithful local-hosted setup
### Instructor
1. Open `HVT02_SlideFaithful_LocalHosted/Instructor_Target_Box`
2. Start the target:
   - Windows: `py lab_manager.py start`
   - Linux: `python3 lab_manager.py start`
3. Note the printed instructor IP
4. Share this hosts entry with students:
   - `<INSTRUCTOR_IP> ransom-leak-portal.io`

### Students
1. Open `HVT02_SlideFaithful_LocalHosted/Student_Operator_Kit`
2. Add the instructor mapping to the hosts file
3. In VS Code:
   - select a Python interpreter
   - run `py lab_manager.py start`
   - run `py scripts\vscode_runner.py --step all`

## Offline full setup
1. Open `HVT02_Offline_Full`
2. Start the lab:
   - Windows: `py lab_manager.py start`
   - Linux: `python3 lab_manager.py start`
3. Show ports:
   - Windows: `py lab_manager.py show`
   - Linux: `python3 lab_manager.py show`
4. Run the full flow:
   - Windows: `py scripts\vscode_runner.py --step all`
   - Linux: `python3 scripts/vscode_runner.py --step all`
5. Stop the lab when finished

## Key student outputs
- `bola_exfil_log.csv`
- `evidence_manifest.txt`
- terminal output from `ct_searcher.py`
- terminal output from `icon_hasher.py`
- terminal output from `log_slicer.py`

## Notes
- This is a local training-only simulation.
- No live internet lookups are required.
- The lab is designed to teach sequence, evidence handling, and analytical interpretation.


## Expanded bundle note
This package preserves the original objective chain while increasing the amount of data and realism for stronger cohorts.
