# HVT-02 Optional Challenge Addendum

1. From `bola_exfil_log.csv`, identify:
   - the most common country
   - the most common sector
   - the number of paid vs unpaid victims

2. From `data/mock_ct_logs.json`, identify:
   - every non-proxied host
   - every Cloudflare-proxied host
   - which burned relay is no longer part of the current edge shield

3. From `data/mock_favicon_index.csv`, build a quick cluster note:
   - how many domains share the hash
   - which look like press relays
   - which look like negotiation / payment portals

4. From `logs/attacker_intel.log`, identify:
   - whether recon activity predates the recovered admin login
   - which indicators suggest mirror mapping or API enumeration
