# HVT-02 Expanded Instructor Walkthrough

## Preserved core answers
- Exposed origin candidate: `127.0.0.1`
- WAF: Cloudflare-style edge shield
- Favicon dork: `http.favicon.hash:1369335675`
- Open endpoint: `/api/v1/victims/`
- Admin username: `Admin_Phantom`
- Admin IP: `192.168.1.55`
- Admin login timestamp: `17/Mar/2026:23:15:00 +0000`

## Expanded content added for stronger cohorts
- victim registry increased to 250 structured records
- richer public portal and more context pages
- multiple non-proxied CT entries instead of one obvious single clue
- larger favicon cluster for network-mapping discussion
- larger Apache log to make the slicing stage feel realistic
- more visible false positives in the API wordlist

## Suggested 75-minute pacing
- 0–10 min: setup and seal check
- 10–20 min: CT review and WAF confirmation
- 20–35 min: favicon hash and API route enumeration
- 35–50 min: BOLA export and quick triage of CSV
- 50–60 min: log slicing and evidence sealing
- 60–75 min: optional analysis of country / sector / mirror clustering

## Common errors
- using the domain without the correct host header when pointing tools at an IP
- assuming every HTTP 200 is the target rather than validating content
- forgetting that the log slicer is faster than opening the large log manually
- sealing only the CSV and not the seized log
