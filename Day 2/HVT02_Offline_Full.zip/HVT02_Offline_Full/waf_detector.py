import argparse, urllib.request
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--url", default="http://ransom-leak-portal.io/"); args=ap.parse_args()
    print("--- WAF DETECTOR ---")
    req = urllib.request.Request(args.url, headers={"User-Agent":"Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=10) as r:
        server = r.headers.get("Server",""); ray = r.headers.get("CF-RAY","")
        print(f"[*] HTTP {r.status}")
        print(f"[*] Server header: {server}")
        print("[!] Simulated Cloudflare-style WAF detected" if "cloudflare" in server.lower() or ray else "[*] No edge shield signature detected")
if __name__ == "__main__": main()
