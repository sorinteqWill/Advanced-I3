def mmh3_32(data: bytes, seed: int = 0) -> int:
    c1 = 0xcc9e2d51; c2 = 0x1b873593; length = len(data); h1 = seed; roundedEnd = length & 0xfffffffc
    for i in range(0, roundedEnd, 4):
        k1 = data[i] | (data[i+1] << 8) | (data[i+2] << 16) | (data[i+3] << 24)
        k1 = (k1 * c1) & 0xFFFFFFFF; k1 = ((k1 << 15) | (k1 >> 17)) & 0xFFFFFFFF; k1 = (k1 * c2) & 0xFFFFFFFF
        h1 ^= k1; h1 = ((h1 << 13) | (h1 >> 19)) & 0xFFFFFFFF; h1 = (h1 * 5 + 0xe6546b64) & 0xFFFFFFFF
    k1 = 0; val = length & 0x03
    if val == 3: k1 = data[roundedEnd+2] << 16
    if val in (2,3): k1 |= data[roundedEnd+1] << 8
    if val in (1,2,3):
        k1 |= data[roundedEnd]; k1 = (k1 * c1) & 0xFFFFFFFF; k1 = ((k1 << 15) | (k1 >> 17)) & 0xFFFFFFFF; k1 = (k1 * c2) & 0xFFFFFFFF; h1 ^= k1
    h1 ^= length; h1 ^= h1 >> 16; h1 = (h1 * 0x85ebca6b) & 0xFFFFFFFF; h1 ^= h1 >> 13; h1 = (h1 * 0xc2b2ae35) & 0xFFFFFFFF; h1 ^= h1 >> 16
    return -((~h1 + 1) & 0xFFFFFFFF) if h1 & 0x80000000 else h1
import argparse, base64, urllib.request
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--url", default="http://ransom-leak-portal.io/favicon.ico"); args=ap.parse_args()
    print("--- ICON HASHER ---")
    req = urllib.request.Request(args.url, headers={"User-Agent":"Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=10) as r: content = r.read()
    fav_hash = mmh3_32(base64.b64encode(content))
    print(f"[✓] MurmurHash3: {fav_hash}")
    print(f"[✓] Shodan dork: http.favicon.hash:{fav_hash}")
if __name__ == "__main__": main()
