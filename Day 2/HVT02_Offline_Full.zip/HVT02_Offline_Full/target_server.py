import argparse, json, random, time
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / "assets"
DATA = ROOT / "data"

COUNTRIES = ["UK","DE","US","FR","NL","SE","PL","ES","IT","CA"]
SECTORS = ["Legal","Manufacturing","Finance","Healthcare","Logistics","LocalGov","Education","Retail","Energy","Media"]
ACCESS = ["VPN creds","Citrix reuse","RMM implant","Phished O365","Exposed RDP","Helpdesk reset","Token theft","Legacy broker"]
STATUS = ["Queued","Negotiating","Published","Paid","Hold"]
NEGOTIATORS = [f"handler_{i}" for i in range(1,21)]

victims_db = {}
for i in range(1, 251):
    victims_db[i] = {
        "user_id": i,
        "username": f"Victim_{i:03d}_Corp",
        "email": f"admin@victim{i:03d}corp.example",
        "crypto_wallet": f"bc1q{i:06d}phantom{(i*17)%999999:06d}{(i*7)%97:02d}",
        "ransom_paid": bool(i % 4 == 0),
        "negotiator": NEGOTIATORS[i % len(NEGOTIATORS)],
        "country": COUNTRIES[i % len(COUNTRIES)],
        "sector": SECTORS[i % len(SECTORS)],
        "initial_access": ACCESS[i % len(ACCESS)],
        "exfil_gb": round(8 + ((i * 3.7) % 412), 1),
        "status": STATUS[i % len(STATUS)],
        "publication_window_utc": f"2026-03-{(i % 27) + 1:02d}T{(8 + i) % 24:02d}:{(i * 7) % 60:02d}:00Z",
        "note": f"mirror_cluster_{(i % 6) + 1}"
    }

UUID_LIST = [
    "550e8400-e29b-41d4-a716-446655440000",
    "f47ac10b-58cc-4372-a567-0e02b2c3d479",
    "d9428888-122b-11e1-b85c-61cd3cbb3210",
    "7c9e6679-7425-40de-944b-e07fc1f90ae7",
    "16fd2706-8baf-433b-82eb-8c7fada847da",
]
RATE = {}

def html_page(title, body_html):
    css = """
    <style>
    body{font-family:Segoe UI,Arial,sans-serif;background:#0c1118;color:#e8eef6;margin:0}
    .wrap{max-width:1180px;margin:0 auto;padding:28px}
    header{background:linear-gradient(90deg,#101826,#18263c);border-bottom:1px solid #24364f}
    nav a{color:#9dd2ff;text-decoration:none;margin-right:18px;font-size:14px}
    .badge{display:inline-block;background:#8b1e1e;color:#fff;padding:4px 10px;border-radius:999px;font-size:12px;margin-bottom:16px}
    h1,h2,h3{margin:0 0 14px 0}
    .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px}
    .card{background:#111a27;border:1px solid #24364f;border-radius:14px;padding:18px}
    .muted{color:#9ab0c8}.warn{color:#ffb4b4}.ok{color:#96f0b6}.hi{color:#ffe08a}
    table{width:100%;border-collapse:collapse;margin-top:12px}
    th,td{border-bottom:1px solid #24364f;padding:10px;text-align:left;vertical-align:top}
    input{width:100%;padding:12px;border-radius:8px;border:1px solid #2a3c58;background:#09111b;color:#fff;margin-bottom:12px}
    .btn{display:inline-block;padding:10px 16px;background:#184e77;border-radius:10px;color:#fff;text-decoration:none}
    .small{font-size:12px}
    code{background:#08111a;padding:2px 6px;border-radius:6px}
    footer{padding:24px;color:#9ab0c8;border-top:1px solid #24364f;margin-top:28px}
    </style>"""
    nav = "<header><div class='wrap'><div class='badge'>Phantom Ransomware Crew</div><h1>ransom-leak-portal.io</h1><nav><a href='/'>Home</a><a href='/victims'>Victims</a><a href='/announcements'>Announcements</a><a href='/faq'>FAQ</a><a href='/press'>Press</a><a href='/mirrors'>Mirrors</a><a href='/status'>Status</a><a href='/login'>Partner Access</a></nav></div></header>"
    return f"<!doctype html><html><head><meta charset='utf-8'><title>{title}</title>{css}</head><body>{nav}<div class='wrap'>{body_html}<footer>All disclosures are time-limited. Negotiations via secure channel only. <!-- publication mirrors reuse same brand assets and icon pack --></footer></div></body></html>".encode("utf-8")

class Handler(BaseHTTPRequestHandler):
    server_version = "cloudflare"
    sys_version = ""

    def _hit(self):
        now = time.time()
        key = self.client_address[0]
        RATE.setdefault(key, [])
        RATE[key] = [t for t in RATE[key] if now - t < 2]
        RATE[key].append(now)
        return len(RATE[key])

    def _write(self, code, content, ctype="text/html; charset=utf-8", extra_headers=None):
        self.send_response(code)
        self.send_header("Server", "cloudflare")
        self.send_header("CF-RAY", "mock-ray-id-12345")
        self.send_header("X-Powered-By", "PhantomStack")
        self.send_header("X-Cluster", "mirror-alpha")
        self.send_header("Content-Type", ctype)
        if extra_headers:
            for k, v in extra_headers.items():
                self.send_header(k, v)
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def do_GET(self):
        path = urlparse(self.path).path
        query = parse_qs(urlparse(self.path).query)

        if path.startswith("/api/") and self._hit() > 250:
            self._write(429, b'{"error":"Too Many Requests"}', "application/json")
            return

        if path == "/":
            body = """
            <div class='grid'>
              <div class='card'><h2>Leak Operations Dashboard</h2><p class='muted'>Primary publication node for victim disclosures and negotiation status.</p><p><a class='btn' href='/victims'>Open leak registry</a></p></div>
              <div class='card'><h2>Network Status</h2><p class='ok'>Mirror online</p><p class='muted'>Caching tier protected by edge shield. Origin hidden.</p><p class='small hi'>Partner tooling still references legacy API routes.</p></div>
              <div class='card'><h2>Partner Guidance</h2><p class='muted'>Approved brokers can access the partner portal to verify wallet routing and publication timing.</p><p class='small muted'>Mirror assets remain synchronized across publication domains.</p></div>
            </div>
            <div class='grid' style='margin-top:18px'>
              <div class='card'><h2>Publication Rules</h2><ul><li>Default leak window: 72 hours</li><li>Media mirrors inherit favicon + brand palette</li><li>Legacy broker routes retained for compatibility</li></ul></div>
              <div class='card'><h2>Telemetry</h2><table><tr><th>Region</th><th>Active Cases</th></tr><tr><td>UK</td><td>14</td></tr><tr><td>DE</td><td>11</td></tr><tr><td>US</td><td>19</td></tr><tr><td>NL</td><td>7</td></tr></table></div>
              <div class='card'><h2>Latest Statement</h2><p>We release only after payment windows expire. Press inquiries are ignored.</p><p class='small muted'>Fingerprint note: Brand assets distributed across multiple publication mirrors.</p></div>
            </div>
            """
            self._write(200, html_page("Home", body))
            return

        if path == "/victims":
            rows = "".join(
                f"<tr><td>Victim_{i:03d}_Corp</td><td>{victims_db[i]['status']}</td><td>{victims_db[i]['country']}</td><td>{victims_db[i]['sector']}</td><td>{victims_db[i]['exfil_gb']} GB</td></tr>"
                for i in range(1, 16)
            )
            self._write(200, html_page("Victims", f"<div class='card'><h2>Published Registry</h2><table><tr><th>Victim</th><th>Status</th><th>Region</th><th>Sector</th><th>Exfil</th></tr>{rows}</table><p class='small muted'>Only a subset is shown in the web registry. Structured detail remains in API tooling.</p></div>"))
            return

        if path == "/announcements":
            body = """
            <div class='card'><h2>Announcements</h2>
            <p>Mirror maintenance scheduled for 18 March. Partner access remains available.</p>
            <p class='muted'>Media mirror failover testing begins 19 March 03:00 UTC.</p>
            <p class='small warn'>Legacy structured export paths remain enabled for older broker dashboards.</p>
            </div>
            """
            self._write(200, html_page("Announcements", body))
            return

        if path == "/faq":
            body = """
            <div class='card'><h2>FAQ</h2>
            <p><strong>Q:</strong> How do partners authenticate?</p>
            <p class='muted'><strong>A:</strong> Access tokens are issued per operation. Legacy routes remain enabled for backward compatibility.</p>
            <p><strong>Q:</strong> Which data feeds remain compatible?</p>
            <p class='muted'><strong>A:</strong> Victim registry, summary reports, and historical UUID exports remain accessible to old partner tooling.</p>
            <!-- operator-note: keep v1 registry available until broker migration completes -->
            </div>
            """
            self._write(200, html_page("FAQ", body))
            return

        if path == "/press":
            body = """
            <div class='card'><h2>Press Kit</h2>
            <p class='muted'>Media mirrors reuse the same brand identity assets. Search engines and scanners often collapse them into one cluster.</p>
            <p class='small muted'>Press relay domains share icon pack + analytics fingerprint.</p>
            <table><tr><th>Channel</th><th>Status</th></tr><tr><td>press relay</td><td>online</td></tr><tr><td>cdn relay</td><td>online</td></tr><tr><td>blog relay</td><td>warming</td></tr></table>
            </div>
            """
            self._write(200, html_page("Press", body))
            return

        if path == "/mirrors":
            mirrors = "".join(f"<tr><td>mirror-{i}</td><td>{['EU','NA','APAC'][i%3]}</td><td>{['warm','hot','cold'][i%3]}</td></tr>" for i in range(1,10))
            self._write(200, html_page("Mirrors", f"<div class='card'><h2>Mirror Fleet</h2><table><tr><th>Mirror</th><th>Zone</th><th>Status</th></tr>{mirrors}</table><p class='small muted'>Brand assets inherited via shared deployment profile.</p></div>"))
            return

        if path == "/status":
            self._write(200, html_page("Status", "<div class='card'><h2>Status</h2><p class='ok'>Publishing queue stable.</p><p class='muted'>Partner API v1 remains reachable for legacy automation. v2 gateway under maintenance.</p><p class='small hi'>Health endpoint available for broker diagnostics.</p></div>"))
            return

        if path == "/login":
            self._write(200, html_page("Partner Access", "<div class='card'><h2>Partner Access</h2><p class='muted'>Authorised negotiators only.</p><input placeholder='Username'/><input placeholder='Password' type='password'/><a class='btn' href='/portal'>Authenticate</a><p class='small warn'>Warning: legacy API still required for some partner tooling.</p></div>"))
            return

        if path == "/portal":
            self._write(200, html_page("Portal", "<div class='card'><h2>Partner Console</h2><p class='muted'>Operational summaries removed from web view. Use API for structured access.</p><p class='small muted'>Old broker dashboards still call <code>/api/v1/victims/</code> directly.</p></div>"))
            return

        if path == "/robots.txt":
            self._write(200, b"User-agent: *\nDisallow: /portal\nDisallow: /api/\nDisallow: /download/\n", "text/plain")
            return

        if path == "/favicon.ico":
            self._write(200, (ASSETS / "favicon.ico").read_bytes(), "image/x-icon")
            return

        if path == "/lab/ctfeed.json":
            self._write(200, (DATA / "mock_ct_logs.json").read_bytes(), "application/json")
            return

        if path == "/lab/favicon_index.csv":
            self._write(200, (DATA / "mock_favicon_index.csv").read_bytes(), "text/csv")
            return

        if path == "/lab/attacker_intel.log":
            self._write(200, (ROOT / "logs" / "attacker_intel.log").read_bytes(), "text/plain")
            return

        if path == "/api/v1/victims/":
            payload = {
                "endpoint": "victim registry",
                "auth": "legacy bearer token accepted",
                "usage": "append integer ID to path and provide Authorization: Bearer <token>",
                "records": len(victims_db),
                "notes": "v1 retained for broker compatibility"
            }
            self._write(200, json.dumps(payload).encode(), "application/json")
            return

        if path == "/api/v1/health":
            payload = {"status": "ok", "mirror_cluster": "alpha", "legacy_mode": True, "queue_depth": 12}
            self._write(200, json.dumps(payload).encode(), "application/json")
            return

        if path == "/api/v1/reports/summary":
            summary = {
                "active_cases": sum(1 for v in victims_db.values() if v["status"] in ("Queued","Negotiating")),
                "published_cases": sum(1 for v in victims_db.values() if v["status"] == "Published"),
                "countries": sorted(list({v["country"] for v in victims_db.values()})),
                "shared_brand_assets": True
            }
            self._write(200, json.dumps(summary).encode(), "application/json")
            return

        if path.startswith("/api/v1/victims/"):
            try:
                victim_id = int(path.rstrip("/").split("/")[-1])
            except ValueError:
                self._write(404, b'{"error":"Not Found"}', "application/json")
                return
            if "Bearer" not in self.headers.get("Authorization", ""):
                self._write(401, b'{"error":"Unauthorized. Bearer token required."}', "application/json")
                return
            victim = victims_db.get(victim_id)
            if victim:
                self._write(200, json.dumps(victim).encode(), "application/json")
                return
            self._write(404, b'{"error":"Victim ID not found"}', "application/json")
            return

        if path.startswith("/api/v2/victims/"):
            self._write(403, b'{"error":"Forbidden"}', "application/json")
            return

        if path in ["/.env", "/.git/config", "/admin", "/server-status", "/backup", "/private", "/reports/export"]:
            self._write(403, b"Forbidden", "text/plain")
            return

        if path == "/api/users/list":
            self._write(200, json.dumps({"uuids": UUID_LIST}).encode(), "application/json")
            return

        if path == "/download/full_dump":
            limit = int(query.get("limit", ["100"])[0])
            self._write(200, json.dumps({"items": [victims_db[i] for i in range(1, min(limit, len(victims_db)) + 1)]}).encode(), "application/json")
            return

        self._write(404, b"Not Found", "text/plain")

    def log_message(self, fmt, *args):
        return

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=8000)
    args = ap.parse_args()
    print(f"[*] Starting HVT-02 target on {args.host}:{args.port}")
    httpd = ThreadingHTTPServer((args.host, args.port), Handler)
    httpd.serve_forever()

if __name__ == "__main__":
    main()
