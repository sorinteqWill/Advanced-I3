import argparse, json, os, socket, subprocess, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parent
ENV_FILE = ROOT / ".lab_env.json"
PID_FILE = ROOT / ".lab_pids.json"
def find_free_port(start=8000):
    p = start
    while True:
        with socket.socket() as s:
            try: s.bind(("127.0.0.1", p)); return p
            except OSError: p += 1
def my_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80)); return s.getsockname()[0]
    except Exception: return "127.0.0.1"
    finally: s.close()
def start():
    target_port = find_free_port(8000); score_port = find_free_port(target_port+1)
    target = subprocess.Popen([sys.executable, "target_server.py", "--host", "0.0.0.0", "--port", str(target_port)], cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    score = subprocess.Popen([sys.executable, "-m", "http.server", str(score_port), "--directory", "scoreboard"], cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(1.0)
    cfg={"target_port":target_port,"scoreboard_port":score_port,"base_url":f"http://127.0.0.1:{target_port}","host_header":"ransom-leak-portal.io","instructor_ip":my_ip()}
    ENV_FILE.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    PID_FILE.write_text(json.dumps({"target_pid":target.pid,"score_pid":score.pid}, indent=2), encoding="utf-8")
    print("[✓] Lab started")
    print(json.dumps(cfg, indent=2))
    print(f"[*] Add to student /etc/hosts for LAN mode: {cfg['instructor_ip']} ransom-leak-portal.io")
def stop():
    if not PID_FILE.exists(): print("[*] No running lab metadata found."); return
    pids = json.loads(PID_FILE.read_text(encoding="utf-8"))
    for key in ["target_pid","score_pid"]:
        pid = pids.get(key)
        if pid:
            try:
                if os.name == "nt": subprocess.call(["taskkill","/PID",str(pid),"/F"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                else: os.kill(pid, 15)
            except Exception: pass
    print("[✓] Lab stopped")
def show():
    print(ENV_FILE.read_text(encoding="utf-8") if ENV_FILE.exists() else "[-] No .lab_env.json present")
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("cmd", choices=["start","stop","show"]); args=ap.parse_args()
    {"start":start,"stop":stop,"show":show}[args.cmd]()
if __name__ == "__main__": main()
